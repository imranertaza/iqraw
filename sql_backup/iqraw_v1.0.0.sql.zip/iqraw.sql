-- phpMyAdmin SQL Dump
-- version 5.1.1deb3+bionic1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 30, 2023 at 10:47 AM
-- Server version: 5.7.41-0ubuntu0.18.04.1
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iqraw`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 1924329315, 'Noapara, Abhaynagar, Jessore', 'profile.jpg', NULL, NULL, 1, '1', 1, '2018-11-21 18:05:40', 1, '2019-11-10 22:20:42', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `badge`
--

CREATE TABLE `badge` (
  `badge_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `ranking` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `logo` varchar(256) DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) DEFAULT NULL,
  `updateDtm` timestamp NULL DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `name`, `logo`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 'BAGS', '1672583061_dd873b42c3e098c9a1ec.png', '2023-01-01 13:03:57', NULL, NULL, NULL, NULL, NULL),
(2, 'DN', '1672582327_15bfa997308a2de8c288.jpg', '2023-01-01 13:21:15', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter`
--

CREATE TABLE `chapter` (
  `chapter_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hand_note` varchar(155) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter`
--

INSERT INTO `chapter` (`chapter_id`, `subject_id`, `name`, `hand_note`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, '1st', 'hand_note_1672637873_fe339615acd5300a1696.pdf', '1', 1, '2022-12-26 18:34:58', NULL, '2023-01-02 11:37:53', NULL, NULL),
(2, 1, '2nd', 'hand_note_1672577542_6467aae2cea81e7d2485.pdf', '1', 1, '2022-12-26 18:35:11', NULL, '2023-01-01 18:52:22', NULL, NULL),
(3, 1, '3rd', 'hand_note_1672577573_ff60975969f56799c629.pdf', '1', 1, '2022-12-26 18:35:23', NULL, '2023-01-01 18:52:53', NULL, NULL),
(4, 1, '4th', 'hand_note_1672637949_0930d49e250297941161.pdf', '1', 1, '2022-12-26 18:35:36', NULL, '2023-01-02 11:39:09', NULL, NULL),
(5, 1, '5th', NULL, '1', 1, '2022-12-26 18:35:49', NULL, '2022-12-26 18:35:49', NULL, NULL),
(6, 2, '1st', NULL, '1', 1, '2022-12-26 18:36:11', NULL, '2022-12-26 18:36:11', NULL, NULL),
(7, 2, '2nd', NULL, '1', 1, '2022-12-26 18:36:24', NULL, '2022-12-26 18:36:24', NULL, NULL),
(8, 2, '3rd', NULL, '1', 1, '2022-12-26 18:36:39', NULL, '2022-12-26 18:36:39', NULL, NULL),
(9, 2, '4th', NULL, '1', 1, '2022-12-26 18:37:00', NULL, '2022-12-26 18:37:00', NULL, NULL),
(10, 2, '5th', NULL, '1', 1, '2022-12-26 18:37:30', NULL, '2022-12-26 18:37:30', NULL, NULL),
(11, 3, '1st', NULL, '1', 1, '2022-12-26 18:37:48', NULL, '2022-12-26 18:37:48', NULL, NULL),
(12, 3, '2nd', NULL, '1', 1, '2022-12-26 18:38:00', NULL, '2022-12-26 18:38:00', NULL, NULL),
(13, 3, '3rd', NULL, '1', 1, '2022-12-26 18:39:24', NULL, '2022-12-26 18:39:24', NULL, NULL),
(14, 3, '4th', NULL, '1', 1, '2022-12-26 18:39:35', NULL, '2022-12-26 18:39:35', NULL, NULL),
(15, 3, '5th', NULL, '1', 1, '2022-12-26 18:39:48', NULL, '2022-12-26 18:39:48', NULL, NULL),
(16, 4, '1st', NULL, '1', 1, '2022-12-28 20:43:05', NULL, '2022-12-28 20:43:05', NULL, NULL),
(17, 36, '1', 'hand_note_1672550244_3d05ddcd7de628642125.pdf', '1', 1, '2022-12-29 20:28:57', NULL, '2023-01-01 11:17:24', NULL, NULL),
(18, 36, '2', 'hand_note_1672576695_a473d3030ecdd364e420.pdf', '1', 1, '2022-12-29 20:29:07', NULL, '2023-01-01 18:38:15', NULL, NULL),
(19, 25, 'test', 'hand_note_1672488571_a58cb5abad0b1c9ce43b.pdf', '1', 1, '2022-12-31 18:09:31', NULL, '2022-12-31 18:09:31', NULL, NULL),
(20, 39, '1st', 'hand_note_1672489280_9555d715679659fff4aa.pdf', '1', 1, '2022-12-31 18:18:33', NULL, '2022-12-31 18:21:20', NULL, NULL),
(21, 4, '2nd', 'hand_note_1672489282_ee2ff4040d5ade8402cb.pdf', '1', 1, '2022-12-31 18:21:22', NULL, '2022-12-31 18:21:22', NULL, NULL),
(22, 40, '1st', 'hand_note_1672489327_2b4844b91f2828d98d2a.pdf', '1', 1, '2022-12-31 18:22:07', NULL, '2022-12-31 18:22:07', NULL, NULL),
(23, 41, '1st', 'hand_note_1672498241_8499e6f23ac4a05d3d7c.pdf', '1', 1, '2022-12-31 20:50:41', NULL, '2022-12-31 20:50:41', NULL, NULL),
(25, 8, '1', NULL, '1', 1, '2023-01-01 19:15:00', NULL, '2023-01-01 19:15:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter_exam_joined`
--

CREATE TABLE `chapter_exam_joined` (
  `chapter_joined_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) UNSIGNED DEFAULT NULL,
  `incorrect_answers` int(11) UNSIGNED DEFAULT NULL,
  `earn_points` int(11) UNSIGNED DEFAULT NULL,
  `earn_coins` int(11) UNSIGNED DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter_exam_joined`
--

INSERT INTO `chapter_exam_joined` (`chapter_joined_id`, `chapter_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, NULL, NULL, NULL, NULL, 1, '2022-12-27 19:05:25', NULL, '2022-12-27 19:05:25', NULL, NULL),
(2, 16, 2, NULL, NULL, NULL, NULL, 2, '2022-12-28 20:46:43', NULL, '2022-12-28 20:46:43', NULL, NULL),
(3, 17, 1, NULL, NULL, NULL, NULL, 1, '2022-12-29 20:47:31', NULL, '2022-12-29 20:47:31', NULL, NULL),
(4, 18, 1, 3, 1, 3, 3, 1, '2022-12-29 20:53:48', NULL, '2022-12-29 20:54:04', NULL, NULL),
(5, 19, 5, 2, NULL, 2, 2, 5, '2022-12-31 18:21:13', NULL, '2022-12-31 18:21:20', NULL, NULL),
(6, 16, 1, 15, NULL, 15, 15, 1, '2022-12-31 20:37:07', NULL, '2022-12-31 20:37:20', NULL, NULL),
(7, 23, 1, 1, NULL, 1, 1, 1, '2022-12-31 20:57:45', NULL, '2022-12-31 20:57:49', NULL, NULL),
(8, 21, 2, 2, NULL, 2, 2, 2, '2022-12-31 20:59:49', NULL, '2022-12-31 21:00:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter_quiz`
--

CREATE TABLE `chapter_quiz` (
  `quiz_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter_quiz`
--

INSERT INTO `chapter_quiz` (`quiz_id`, `chapter_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'আতা গাছে কী পাখি?', 'তোতা', 'কাক', 'কোকিল', 'ময়না', 'one', '1', 1, '2022-12-26 19:14:31', NULL, '2022-12-26 19:14:31', NULL, NULL),
(2, 1, 'ডালিম গাছে কী আছে?', 'বৌ', 'মৌ', 'কৌ', 'রৌ', 'two', '1', 1, '2022-12-26 19:14:54', NULL, '2022-12-26 19:14:54', NULL, NULL),
(3, 17, 'Selet        2', '2', '1', 'too', 'Two', 'one', '1', 1, '2022-12-29 20:50:12', NULL, '2022-12-29 20:50:12', NULL, NULL),
(4, 17, '3', '3', '3', '3', '3', 'three', '1', 1, '2022-12-29 20:50:32', NULL, '2022-12-29 20:50:32', NULL, NULL),
(5, 17, '4', '4', '4', '4', '4', 'four', '1', 1, '2022-12-29 20:50:48', NULL, '2022-12-29 20:50:48', NULL, NULL),
(6, 18, '1', '1', '1', '1', '1', 'one', '1', 1, '2022-12-29 20:51:04', NULL, '2022-12-29 20:51:04', NULL, NULL),
(7, 18, '2', '2', '2', '2', '2', 'two', '1', 1, '2022-12-29 20:51:19', NULL, '2022-12-29 20:51:19', NULL, NULL),
(8, 18, '3', '3', '3', '3', '3', 'three', '1', 1, '2022-12-29 20:51:36', NULL, '2022-12-29 20:51:36', NULL, NULL),
(9, 18, '4', '4', '4', '4', '4', 'four', '1', 1, '2022-12-29 20:51:50', NULL, '2022-12-29 20:51:50', NULL, NULL),
(10, 19, 'abcd - bcd', 'a', 'b', 'c', 'd', 'one', '1', 1, '2022-12-31 18:18:11', NULL, '2022-12-31 18:18:11', NULL, NULL),
(11, 19, '5-2', '4', '5', '3', '2', 'three', '1', 1, '2022-12-31 18:18:42', NULL, '2022-12-31 18:18:42', NULL, NULL),
(12, 21, 'আতা গাছে কী পাখি?', 'তোতা', 'কাক', 'কৌ', 'রৌ', 'one', '1', 1, '2022-12-31 20:28:58', NULL, '2022-12-31 20:58:09', NULL, NULL),
(13, 21, 'ডালিম গাছে কী আছে?', 'তোতা', 'মৌ', 'কোকিল', 'ময়না', 'two', '1', 1, '2022-12-31 20:29:38', NULL, '2022-12-31 20:58:20', NULL, NULL),
(14, 1, 'বিড়ালের কয়টি পা থাকে?', '২', '৩', '৫', '8', 'four', '1', 1, '2023-01-12 20:57:57', NULL, '2023-01-12 20:57:57', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter_video`
--

CREATE TABLE `chapter_video` (
  `video_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter_video`
--

INSERT INTO `chapter_video` (`video_id`, `chapter_id`, `name`, `URL`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 16, 'Admin', 'C29SRqtV43Y', '1', 1, '2022-12-28 20:43:20', NULL, '2022-12-28 20:43:20', NULL, NULL),
(3, 17, '1st Video', '2Q6Hx6Tv2jI', '1', 1, '2022-12-29 20:38:21', NULL, '2022-12-29 20:38:21', NULL, NULL),
(4, 18, '2ed video', '9QFZssiVcjI', '1', 1, '2022-12-29 20:42:42', NULL, '2022-12-29 20:42:42', NULL, NULL),
(5, 19, 'Pemancing manapun pasti yakin kalau spot ini banyak ikannya', 'v_I8IOjSI5k', '1', 1, '2022-12-31 18:16:24', NULL, '2022-12-31 18:16:24', NULL, NULL),
(6, 20, 'dsd', 'ZcIQ7xkFxd8', '1', 1, '2022-12-31 18:55:55', NULL, '2022-12-31 18:55:55', NULL, NULL),
(7, 23, '1st', '9QFZssiVcjI', '1', 1, '2022-12-31 20:53:15', NULL, '2022-12-31 20:53:15', NULL, NULL),
(8, 21, 'Admin', 'U2PCw-cyyXA', '1', 1, '2022-12-31 20:59:24', NULL, '2022-12-31 20:59:24', NULL, NULL),
(13, 25, 'VV', 'gUm1uTT56cE', '1', 1, '2023-01-01 19:15:31', NULL, '2023-01-01 19:15:31', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Class 1', '1', 1, '2022-12-26 18:02:24', NULL, '2022-12-26 18:02:24', NULL, NULL),
(2, 'Class 2', '1', 1, '2022-12-26 18:02:39', NULL, '2022-12-26 18:02:39', NULL, NULL),
(3, 'Class 3', '1', 1, '2022-12-26 18:02:47', NULL, '2022-12-26 18:02:47', NULL, NULL),
(4, 'Class 4', '1', 1, '2022-12-26 18:02:54', NULL, '2022-12-26 18:02:54', NULL, NULL),
(5, 'Class 5', '1', 1, '2022-12-26 18:03:03', NULL, '2022-12-26 18:03:03', NULL, NULL),
(6, 'Class 6', '1', 1, '2022-12-26 18:03:10', NULL, '2022-12-26 18:03:10', NULL, NULL),
(7, 'Class 7', '1', 1, '2022-12-26 18:03:17', NULL, '2022-12-26 18:03:17', NULL, NULL),
(8, 'Class 8', '1', 1, '2022-12-26 18:03:24', NULL, '2022-12-26 18:03:24', NULL, NULL),
(9, 'Class 9', '1', 1, '2022-12-26 18:03:31', NULL, '2022-12-26 18:03:31', NULL, NULL),
(10, 'Class 10', '1', 1, '2022-12-26 18:03:39', NULL, '2022-12-26 18:03:39', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class_group`
--

CREATE TABLE `class_group` (
  `class_group_id` int(11) NOT NULL,
  `group_name` varchar(155) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_group`
--

INSERT INTO `class_group` (`class_group_id`, `group_name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Arts', 'Active', 1, '2022-08-15 16:40:20', NULL, '2023-01-01 20:18:13', NULL, NULL),
(2, 'Science', 'Active', 1, '2022-08-15 16:41:03', NULL, '2022-08-15 16:41:03', NULL, NULL),
(3, 'Commerce', 'Active', 1, '2022-08-15 16:41:17', NULL, '2022-08-15 16:41:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class_group_joined`
--

CREATE TABLE `class_group_joined` (
  `class_group_jnt_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `class_group_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_group_joined`
--

INSERT INTO `class_group_joined` (`class_group_jnt_id`, `class_id`, `class_group_id`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 9, 1, 1, '2022-12-26 18:23:22', NULL, NULL, NULL, NULL),
(2, 9, 2, 1, '2022-12-26 18:23:22', NULL, NULL, NULL, NULL),
(3, 9, 3, 1, '2022-12-26 18:23:22', NULL, NULL, NULL, NULL),
(4, 10, 1, 1, '2022-12-26 18:23:38', NULL, NULL, NULL, NULL),
(5, 10, 2, 1, '2022-12-26 18:23:38', NULL, NULL, NULL, NULL),
(6, 10, 3, 1, '2022-12-26 18:23:38', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class_subscribe`
--

CREATE TABLE `class_subscribe` (
  `class_subscribe_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `class_subscription_package_id` int(11) NOT NULL,
  `subs_time` int(11) DEFAULT NULL COMMENT 'Value is calculated with month.',
  `subs_end_date` date NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_subscribe`
--

INSERT INTO `class_subscribe` (`class_subscribe_id`, `std_id`, `class_subscription_package_id`, `subs_time`, `subs_end_date`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(16, 2, 6, 1, '2023-01-30', '1', 2, '2022-12-31 18:50:39', NULL, NULL, NULL, NULL),
(17, 1, 5, 1, '2023-01-30', '1', 1, '2022-12-31 18:53:52', NULL, NULL, NULL, NULL),
(18, 1, 6, 1, '2023-01-30', '1', 1, '2022-12-31 20:36:56', NULL, NULL, NULL, NULL),
(19, 1, 1, 1, '2023-01-31', '1', 1, '2023-01-01 11:12:52', NULL, NULL, NULL, NULL),
(20, 1, 3, 1, '2023-01-31', '1', 1, '2023-01-01 11:14:51', NULL, NULL, NULL, NULL),
(21, 3, 1, 1, '2023-01-31', '1', 3, '2023-01-01 18:28:30', NULL, NULL, NULL, NULL),
(22, 3, 2, 1, '2023-01-31', '1', 3, '2023-01-01 18:32:23', NULL, NULL, NULL, NULL),
(23, 3, 6, 1, '2023-01-31', '1', 3, '2023-01-01 19:10:32', NULL, NULL, NULL, NULL),
(24, 4, 5, 1, '2023-02-02', '1', 4, '2023-01-03 18:39:33', NULL, NULL, NULL, NULL),
(25, 1, 13, 1, '2023-02-06', '1', 1, '2023-01-07 20:33:51', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class_subscribe_package`
--

CREATE TABLE `class_subscribe_package` (
  `class_subscription_package_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `m_fee` float UNSIGNED NOT NULL,
  `3_m_fee` float UNSIGNED DEFAULT NULL,
  `6_m_fee` float UNSIGNED DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_subscribe_package`
--

INSERT INTO `class_subscribe_package` (`class_subscription_package_id`, `class_id`, `class_group_id`, `m_fee`, `3_m_fee`, `6_m_fee`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, NULL, 1, 0, 0, '1', 1, '2022-12-28 18:48:09', NULL, '2022-12-31 11:45:34', NULL, NULL),
(2, 9, NULL, 25, 0, 0, '1', 1, '2022-12-29 20:58:37', NULL, '2022-12-29 20:58:37', NULL, NULL),
(3, 9, 2, 1, 0, 0, '1', 1, '2022-12-29 20:59:41', NULL, '2022-12-29 20:59:41', NULL, NULL),
(5, 9, 1, 200, 0, 0, '1', 1, '2022-12-31 18:13:07', NULL, '2022-12-31 18:13:07', NULL, NULL),
(6, 2, NULL, 50, 0, 0, '1', 1, '2022-12-31 18:47:44', NULL, '2022-12-31 18:47:44', NULL, NULL),
(8, 3, NULL, 4, 0, 0, '1', 1, '2022-12-31 20:48:04', NULL, '2022-12-31 20:48:04', NULL, NULL),
(9, 5, NULL, 1, 0, 0, '1', 1, '2022-12-31 20:48:09', NULL, '2022-12-31 20:48:09', NULL, NULL),
(11, 4, NULL, 1, 0, 0, '1', 1, '2022-12-31 20:48:35', NULL, '2022-12-31 20:48:35', NULL, NULL),
(12, 7, NULL, 3, 0, 0, '1', 1, '2022-12-31 20:48:47', NULL, '2022-12-31 20:48:47', NULL, NULL),
(13, 8, NULL, 1, 0, 0, '1', 1, '2022-12-31 20:48:53', NULL, '2022-12-31 20:48:53', NULL, NULL),
(14, 10, 1, 1, 0, 0, '1', 1, '2022-12-31 20:49:06', NULL, '2022-12-31 20:49:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `price` float UNSIGNED DEFAULT NULL,
  `3_m_fee` float UNSIGNED DEFAULT NULL,
  `6_m_fee` float UNSIGNED DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `description`, `price`, `3_m_fee`, `6_m_fee`, `class_id`, `class_group_id`, `image`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'COURSE FOR ALL CLASS', '<div>Sob class <i><u><b>er</b></u></i> jonno course&nbsp;</div>', 88, NULL, NULL, NULL, NULL, 'course_1672057750_95a7a7637357f222cf5e.jpg', '1', 1, '2022-12-26 18:29:10', NULL, NULL, NULL, NULL),
(2, 'English For Class 6', '<div>jhgjxgxg&nbsp; cf</div>', 35, NULL, NULL, 6, NULL, 'course_1672063104_786eecef0f27b1c92516.jpg', '1', 1, '2022-12-26 19:58:24', NULL, NULL, NULL, NULL),
(3, 'Class For 9', 'dfgcf&nbsp;', 101, NULL, NULL, 9, NULL, 'course_1672065965_513eb3616154c55ad800.jpg', '1', 1, '2022-12-26 20:46:05', NULL, NULL, NULL, NULL),
(4, 'Class 9 Science', '<div>8585</div>', 118, NULL, NULL, 9, 2, 'course_1672145331_631ec1923ef63eefa5c6.jpg', '1', 1, '2022-12-27 18:48:51', NULL, NULL, NULL, NULL),
(5, 'Class 7', '<div>1</div>', 1, NULL, NULL, 7, NULL, 'course_1672147213_da7df96a716808badfb6.jpg', '1', 1, '2022-12-27 19:20:13', NULL, NULL, NULL, NULL),
(6, 'Cours for 10 All Group', '<div>sdafdasfdsafadsfdsafav vdv&nbsp;</div>', 2, NULL, NULL, 10, NULL, 'course_1672231189_95dc5faab079980b96b5.jpg', '1', 1, '2022-12-28 18:39:50', NULL, NULL, NULL, NULL),
(7, 'Cours for 9 arts', '<div>a</div>', 1, NULL, NULL, 9, 1, 'course_1672491421_5b118cb6299837116a80.jpg', '1', 1, '2022-12-31 18:57:01', NULL, NULL, NULL, NULL),
(8, 'Cours for 9 Comarcse', '<div>a</div>', 1, NULL, NULL, 9, 3, 'course_1672491483_f0c9ad8c1a61dfcf7012.jpg', '1', 1, '2022-12-31 18:58:03', NULL, NULL, NULL, NULL),
(9, 'Course for 9 sci', '<div>asdf</div>', 1, NULL, NULL, 9, 2, 'course_1672491538_0684f99b01511c176faf.jpg', '1', 1, '2022-12-31 18:58:58', NULL, NULL, NULL, NULL),
(10, 'course for 10 Arts', '<div>asdf</div>', 1, NULL, NULL, 10, 1, 'course_1672491610_dfddc91cc987d6b72ef8.jpg', '1', 1, '2022-12-31 19:00:10', NULL, NULL, NULL, NULL),
(11, 'Course for 10 com', '<div style=\"text-align: center;\">adsf</div><div style=\"text-align: center;\">adfdsf</div><div style=\"text-align: center;\">adfdadfasfadff</div><div style=\"text-align: center;\">afasdfsadfs<span style=\"font-size: 1rem;\">fsd</span></div>', 1, NULL, NULL, 10, 3, 'course_1672491677_0d6ff92ba92f93ea3151.jpg', '1', 1, '2022-12-31 19:01:17', NULL, NULL, NULL, NULL),
(12, 'Cours for 10 sci', '<div>sfsfdad</div>', 88, NULL, NULL, 10, 2, 'course_1672491732_c803e5a2d34a62f86454.jpg', '1', 1, '2022-12-31 19:02:12', NULL, NULL, NULL, NULL),
(13, 'English', '<div>hkfdhgfudighfdfghhug</div>', 20, NULL, NULL, 2, NULL, 'course_1672552789_8da13a03646d31fb3993.jpg', '1', 1, '2023-01-01 11:59:49', NULL, NULL, NULL, NULL),
(14, 'আমার বাংলা ', '<div><table class=\"table-1\"><tbody><tr><td>0 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td></tr><tr><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td></tr><tr><td>1 </td><td>0 </td><td>0 </td><td>0 </td><td>0 </td><td>0 </td><td>1 </td><td>1</td><td>1</td><td>0</td></tr><tr><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>1</td><td>0 </td><td>1 </td></tr><tr><td>0 </td><td>1</td><td>1 </td><td>1 </td><td>1 </td><td>2 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td></tr><tr><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td><td>1 </td></tr><tr><td>0 </td><td>0 </td><td>0 </td><td>1 </td><td>0</td><td>0</td><td>0</td><td>0 </td><td>1 </td><td>0 </td></tr><tr><td>1 </td><td>0 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td></tr><tr><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td></tr><tr><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td><td>0 </td><td>1 </td></tr></tbody></table><br></div>', 10, NULL, NULL, NULL, NULL, 'course_1672662875_63e4388b3579356d5c71.jpg', '1', 1, '2023-01-02 18:34:35', NULL, NULL, NULL, NULL),
(15, 'PSC Bangla Solution', 'jhfnkjdfbgjhglbnhfgvb', 20, NULL, NULL, 5, NULL, 'course_1673189591_060cf72e701c7f68e49c.png', '1', 1, '2023-01-08 20:53:11', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_category`
--

CREATE TABLE `course_category` (
  `course_cat_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `category_name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_category`
--

INSERT INTO `course_category` (`course_cat_id`, `course_id`, `category_name`, `image`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 1, 'Basic', 'category_1672058365_d6b1aad75e05db19f14a.jpg', '1', '2022-12-26 18:39:25', 1, '2022-12-26 18:39:25', NULL, NULL, NULL),
(8, 1, 'Premium', 'category_1672059689_e6b030e605458109606f.jpg', '1', '2022-12-26 19:01:29', 1, '2022-12-26 19:01:29', NULL, NULL, NULL),
(9, 1, 'Premium Plus', 'category_1672060345_553dfad48a45f5863c3b.jpg', '1', '2022-12-26 19:12:25', 1, '2022-12-26 19:12:25', NULL, NULL, NULL),
(10, 2, 'Basic', 'category_1672066455_3d9367f3b552cb3b0750.jpg', '1', '2022-12-26 20:54:15', 1, '2022-12-26 20:54:15', NULL, NULL, NULL),
(11, 3, 'Basic', 'category_1672066478_3b38c491fc7f18e66938.jpg', '1', '2022-12-26 20:54:38', 1, '2022-12-26 20:54:38', NULL, NULL, NULL),
(12, 4, 'Basic', 'category_1672146927_096f22bbab1e25728c14.jpg', '1', '2022-12-27 19:15:27', 1, '2022-12-27 19:15:27', NULL, NULL, NULL),
(13, 10, 'aaa', 'category_1672492624_cae9ecc4b2fe03911d2d.jpg', '1', '2022-12-31 19:17:04', 1, '2022-12-31 19:17:04', NULL, NULL, NULL),
(14, 11, 'aa', 'category_1672495256_7eaabc90af1b741e6add.jpg', '1', '2022-12-31 20:00:56', 1, '2022-12-31 20:00:56', NULL, NULL, NULL),
(15, 12, 'aba', 'category_1672495266_1e116848d2f9b0733e1a.jpg', '1', '2022-12-31 20:01:06', 1, '2022-12-31 20:01:06', NULL, NULL, NULL),
(16, 8, 'nnn', 'category_1672495278_1359f4f68117ce4037cc.jpg', '1', '2022-12-31 20:01:18', 1, '2022-12-31 20:01:18', NULL, NULL, NULL),
(17, 7, 'tr', 'category_1672495322_6d6d69cb8cca2bef5a7a.jpg', '1', '2022-12-31 20:02:02', 1, '2022-12-31 20:02:02', NULL, NULL, NULL),
(18, 9, 'abc', 'category_1672495359_13a9f87174c618711906.jpg', '1', '2022-12-31 20:02:39', 1, '2022-12-31 20:02:39', NULL, NULL, NULL),
(19, 13, 'English for Class 2', 'category_1672552926_76f4ecef1d744e59b725.jpg', '1', '2023-01-01 12:02:06', 1, '2023-01-01 12:02:06', NULL, NULL, NULL),
(20, 15, 'Basic', 'category_1673189732_776f30e097e5a91d6754.png', '1', '2023-01-08 20:55:32', 1, '2023-01-08 20:55:32', NULL, NULL, NULL),
(21, 14, 'বাংলা লিখুন', 'category_1673267038_73853a32d6b00a1d4b9c.jpg', '1', '2023-01-09 18:23:47', 1, '2023-01-09 18:23:58', NULL, NULL, NULL),
(22, 14, 'বাংলা বলুন', 'category_1673267067_499ce2895c06b457c2ea.jpg', '1', '2023-01-09 18:24:27', 1, '2023-01-09 18:24:27', NULL, NULL, NULL),
(23, 14, 'বাংলা শিখুন', 'category_1673267089_2cf1c5e8e4b36e409694.jpg', '1', '2023-01-09 18:24:49', 1, '2023-01-09 18:24:49', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_exam_joined`
--

CREATE TABLE `course_exam_joined` (
  `course_exam_joined_id` int(11) NOT NULL,
  `course_video_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) UNSIGNED DEFAULT NULL,
  `incorrect_answers` int(11) UNSIGNED DEFAULT NULL,
  `earn_points` int(11) UNSIGNED DEFAULT NULL,
  `earn_coins` int(11) UNSIGNED DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_exam_joined`
--

INSERT INTO `course_exam_joined` (`course_exam_joined_id`, `course_video_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 19, 1, 3, NULL, 3, 3, 1, '2023-01-09 19:02:51', NULL, '2023-01-09 19:03:07', NULL, NULL),
(2, 20, 1, 1, NULL, 1, 1, 1, '2023-01-09 19:06:58', NULL, '2023-01-09 19:07:01', NULL, NULL),
(3, 19, 3, 2, 1, 2, 2, 3, '2023-01-09 19:08:07', NULL, '2023-01-09 19:08:25', NULL, NULL),
(4, 19, 2, 3, NULL, 3, 3, 2, '2023-01-09 19:09:26', NULL, '2023-01-09 19:09:42', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_quiz`
--

CREATE TABLE `course_quiz` (
  `course_quiz_id` int(11) NOT NULL,
  `course_video_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_quiz`
--

INSERT INTO `course_quiz` (`course_quiz_id`, `course_video_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 19, 'আতা গাছে কী পাখি?', 'তোতা', 'কাক', 'কোকিল', 'ময়না', 'one', '1', 1, '2023-01-09 18:58:10', NULL, '2023-01-09 18:58:10', NULL, NULL),
(2, 19, 'ডালিম গাছে কী আছে?', 'বৌ', 'মৌ', 'কৌ', 'রৌ', 'two', '1', 1, '2023-01-09 18:58:37', NULL, '2023-01-09 18:58:37', NULL, NULL),
(3, 19, 'বাড়ির কাজে আমরা কী করি?', 'হেলা', 'বকাঝকা', 'সাহায্য', 'সাহায্য করি না', 'three', '1', 1, '2023-01-09 18:59:19', NULL, '2023-01-09 18:59:19', NULL, NULL),
(4, 20, '2', '1', '2', '3', '4', 'two', '1', 1, '2023-01-09 19:04:51', NULL, '2023-01-09 19:04:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_subscribe`
--

CREATE TABLE `course_subscribe` (
  `course_subscribe_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `subs_time` int(11) DEFAULT NULL COMMENT 'Value is calculated with month.',
  `status` enum('1','0') NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_subscribe`
--

INSERT INTO `course_subscribe` (`course_subscribe_id`, `std_id`, `course_id`, `subs_time`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(12, 5, 1, 1, '1', 5, '2022-12-31 18:54:02', NULL, NULL, NULL, NULL),
(13, 2, 1, 1, '1', 2, '2022-12-31 18:58:00', NULL, NULL, NULL, NULL),
(14, 4, 7, 1, '1', 0, '2022-12-31 20:04:47', NULL, NULL, NULL, NULL),
(15, 1, 7, 1, '1', 0, '2022-12-31 20:04:48', NULL, NULL, NULL, NULL),
(16, 1, 1, 1, '1', 0, '2022-12-31 20:07:39', NULL, NULL, NULL, NULL),
(17, 1, 5, 1, '1', 0, '2022-12-31 20:27:41', NULL, NULL, NULL, NULL),
(18, 1, 11, 1, '1', 0, '2022-12-31 20:33:14', NULL, NULL, NULL, NULL),
(19, 1, 6, 1, '1', 0, '2023-01-01 11:09:52', NULL, NULL, NULL, NULL),
(20, 2, 13, 1, '1', 0, '2023-01-01 12:10:12', NULL, NULL, NULL, NULL),
(21, 1, 13, 1, '1', 0, '2023-01-01 12:24:10', NULL, NULL, NULL, NULL),
(22, 1, 14, 1, '1', 0, '2023-01-07 19:20:06', NULL, NULL, NULL, NULL),
(23, 4, 2, 1, '1', 4, '2023-01-08 13:10:37', NULL, NULL, NULL, NULL),
(24, 2, 15, 1, '1', 2, '2023-01-09 18:28:24', NULL, NULL, NULL, NULL),
(25, 1, 15, 1, '1', 0, '2023-01-09 19:02:31', NULL, NULL, NULL, NULL),
(26, 3, 15, 1, '1', 0, '2023-01-09 19:06:57', NULL, NULL, NULL, NULL),
(27, 6, 1, 1, '1', 6, '2023-01-25 20:45:05', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_video`
--

CREATE TABLE `course_video` (
  `course_video_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_cat_id` int(11) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `thumb` text,
  `hand_note` varchar(155) DEFAULT NULL,
  `author` varchar(155) NOT NULL,
  `total_views` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_video`
--

INSERT INTO `course_video` (`course_video_id`, `course_id`, `course_cat_id`, `title`, `URL`, `thumb`, `hand_note`, `author`, `total_views`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 'Video 1', 'vQh7_3kWiX0', 'thumb_1672233332_8a26b5d93b15c06c7209.png', 'hand_note_1672928450_dfaef68ed6de90fe3a5e.pdf', 'Admin', 0, '1', 1, '2022-12-26 18:42:56', NULL, '2023-01-05 20:20:50', NULL, NULL),
(2, 1, 1, 'Video 2', 'kuJ31TTTOM4', 'thumb_1672058612_71c6c0ae2aef2ab82a3b.jpg', 'hand_note_1672928495_bf3b919e7e3787114289.pdf', 'Admin', 0, '1', 1, '2022-12-26 18:43:32', NULL, '2023-01-05 20:21:35', NULL, NULL),
(3, 1, 1, 'Video 3', '_2kPh32Q6qc', 'thumb_1672059375_0eecf28fe033108a9b93.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 18:56:16', NULL, '2022-12-26 18:56:16', NULL, NULL),
(4, 1, 8, 'Video 1', 'xpybPAWZdBk', 'thumb_1672059813_fbe1cdc1bea2e7905e04.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 19:03:33', NULL, '2022-12-26 19:03:33', NULL, NULL),
(5, 1, 8, 'Video 2', 'EqHJDcQHLCY', 'thumb_1672059844_3463421b90d2616fe593.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 19:04:04', NULL, '2022-12-26 19:04:04', NULL, NULL),
(6, 1, 8, 'Video 3', 'u4T5zU9jmfs', 'thumb_1672059876_752c9eb94ae1ef5762e9.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 19:04:36', NULL, '2022-12-26 19:04:36', NULL, NULL),
(7, 1, 9, 'Video 1', '7nB3bwRQs9I', 'thumb_1672060375_28be2b6b3dec42c0b38a.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 19:12:55', NULL, '2022-12-26 19:12:55', NULL, NULL),
(8, 1, 9, 'Video 2', 'BaR3gr754gE', 'thumb_1672060408_95ed87474bb6a0c9d5f3.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 19:13:28', NULL, '2022-12-26 19:13:28', NULL, NULL),
(9, 1, 9, 'Video 3', 'Jp1pDENmUdg', 'thumb_1672060441_8705527dcba4dec17a4d.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-26 19:14:01', NULL, '2022-12-26 19:14:01', NULL, NULL),
(10, 4, 12, '1', '9QFZssiVcjI', 'thumb_1672147057_27acfb281e7451dced78.jpg', NULL, 'Admin', 0, '1', 1, '2022-12-27 19:17:37', NULL, '2022-12-27 19:17:37', NULL, NULL),
(11, 7, 17, 'aaa', 'E1NJQnwWSaQ', 'thumb_1672495381_9d9c25c02c3245f5aee3.jpg', NULL, 'aaaa', 0, '1', 1, '2022-12-31 20:03:01', NULL, '2022-12-31 20:03:01', NULL, NULL),
(12, 8, 16, 'afdadf', 'E1NJQnwWSaQ', 'thumb_1672495398_6ca78a6bcd610ab99c37.jpg', NULL, 'admin', 0, '1', 1, '2022-12-31 20:03:19', NULL, '2022-12-31 20:03:19', NULL, NULL),
(13, 9, 18, 'aa', 'khDn_kFXBec', 'thumb_1672495413_62d979cfba13f771e209.jpg', NULL, 'aaaaa', 0, '1', 1, '2022-12-31 20:03:33', NULL, '2022-12-31 20:03:33', NULL, NULL),
(14, 10, 13, 'adfasdf', 'khDn_kFXBec', 'thumb_1672496402_b7d8874f6baa4334679e.jpg', NULL, 'afdafdsa', 0, '1', 1, '2022-12-31 20:20:02', NULL, '2022-12-31 20:20:02', NULL, NULL),
(15, 11, 15, 'erewer', 'khDn_kFXBec', 'thumb_1672496419_d7500162a6669a2e6116.jpg', NULL, '234', 0, '1', 1, '2022-12-31 20:20:19', NULL, '2022-12-31 20:26:35', NULL, NULL),
(16, 12, 15, 'adsf', 'afd', 'thumb_1672496431_a6a9d6862d4be4b7411b.jpg', NULL, 'adf', 0, '1', 1, '2022-12-31 20:20:31', NULL, '2022-12-31 20:20:31', NULL, NULL),
(17, 13, 19, 'English For Class 2', 'YteekZTKNuE', 'thumb_1672553005_e78ae5dcd5e1c0298bc3.jpg', NULL, 'Admin', 0, '1', 1, '2023-01-01 12:03:25', NULL, '2023-01-01 12:03:25', NULL, NULL),
(18, 1, 1, 'dfgh', 'evshbDjR-So', 'thumb_1672928611_28565ca425c4dcb207a2.jpg', 'hand_note_1672928611_48044b965f140f2d1078.pdf', 'Admin', 0, '1', 1, '2023-01-05 20:23:31', NULL, '2023-01-05 20:23:31', NULL, NULL),
(19, 15, 20, 'Psc', 'EQzWpx_hlVA', 'thumb_1673269927_ebb27f393e1443a48d8c.png', 'hand_note_1673269928_1040d04bae80b1062af0.pdf', 'Admin', 0, '1', 1, '2023-01-08 20:56:25', NULL, '2023-01-09 19:12:08', NULL, NULL),
(20, 14, 21, 'ক থেকে ঁ', 'Ut6vdFRmukg', 'thumb_1673268679_313be2732ecaba2268bb.jpeg', 'hand_note_1673268679_b6c45c619c88f9a28f05.pdf', '???? ?????', 0, '1', 1, '2023-01-09 18:51:19', NULL, '2023-01-09 18:51:19', NULL, NULL),
(21, 14, 22, 'jjdd ddjj ', '3mWuWTokzWU', 'thumb_1673269815_cb9183093421b7d0a1f6.jpeg', 'hand_note_1673269815_3a7436342e0efc721d8c.pdf', 'Admin', 0, '1', 1, '2023-01-09 19:10:15', NULL, '2023-01-09 19:10:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `history_user_coin`
--

CREATE TABLE `history_user_coin` (
  `history_user_coin_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `chapter_joined_id` int(11) DEFAULT NULL,
  `mcq_joined_id` int(11) DEFAULT NULL,
  `qe_joined_id` int(11) DEFAULT NULL,
  `voc_mcq_joined_id` int(11) DEFAULT NULL,
  `course_exam_joined_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double UNSIGNED NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_user_coin`
--

INSERT INTO `history_user_coin` (`history_user_coin_id`, `std_id`, `order_id`, `chapter_joined_id`, `mcq_joined_id`, `qe_joined_id`, `voc_mcq_joined_id`, `course_exam_joined_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 2, NULL, NULL, NULL, 1, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 1, '2022-12-28 04:37:08', 0, '2022-12-28 04:37:08', NULL, NULL, NULL),
(2, 2, NULL, NULL, NULL, 1, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 2, '2022-12-28 04:37:14', 0, '2022-12-28 04:37:14', NULL, NULL, NULL),
(3, 1, NULL, NULL, NULL, 2, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 1, '2022-12-28 14:02:47', 0, '2022-12-28 14:02:47', NULL, NULL, NULL),
(4, 1, NULL, NULL, NULL, 2, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 2, '2022-12-28 14:02:53', 0, '2022-12-28 14:02:53', NULL, NULL, NULL),
(5, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 3, '2022-12-28 14:20:22', 0, '2022-12-28 14:20:22', NULL, NULL, NULL),
(6, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 4, '2022-12-28 14:20:25', 0, '2022-12-28 14:20:25', NULL, NULL, NULL),
(7, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 5, '2022-12-28 14:20:27', 0, '2022-12-28 14:20:27', NULL, NULL, NULL),
(8, 1, NULL, 4, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 38, '2022-12-29 14:53:54', 0, '2022-12-29 14:53:54', NULL, NULL, NULL),
(9, 1, NULL, 4, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 39, '2022-12-29 14:54:02', 0, '2022-12-29 14:54:02', NULL, NULL, NULL),
(10, 1, NULL, 4, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 40, '2022-12-29 14:54:05', 0, '2022-12-29 14:54:05', NULL, NULL, NULL),
(11, 5, NULL, 5, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 1, '2022-12-31 12:21:18', 0, '2022-12-31 12:21:18', NULL, NULL, NULL),
(12, 5, NULL, 5, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 2, '2022-12-31 12:21:21', 0, '2022-12-31 12:21:21', NULL, NULL, NULL),
(13, 2, NULL, NULL, NULL, 5, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 103, '2022-12-31 13:25:53', 0, '2022-12-31 13:25:53', NULL, NULL, NULL),
(14, 2, NULL, NULL, NULL, 5, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 104, '2022-12-31 13:26:00', 0, '2022-12-31 13:26:00', NULL, NULL, NULL),
(15, 2, NULL, NULL, NULL, 5, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 105, '2022-12-31 13:26:00', 0, '2022-12-31 13:26:00', NULL, NULL, NULL),
(16, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 131, '2022-12-31 14:37:10', 0, '2022-12-31 14:37:10', NULL, NULL, NULL),
(17, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 132, '2022-12-31 14:37:14', 0, '2022-12-31 14:37:14', NULL, NULL, NULL),
(18, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 133, '2022-12-31 14:37:14', 0, '2022-12-31 14:37:14', NULL, NULL, NULL),
(19, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 134, '2022-12-31 14:37:15', 0, '2022-12-31 14:37:15', NULL, NULL, NULL),
(20, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 135, '2022-12-31 14:37:15', 0, '2022-12-31 14:37:15', NULL, NULL, NULL),
(21, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 136, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(22, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 137, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(23, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 138, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(24, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 139, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(25, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 140, '2022-12-31 14:37:17', 0, '2022-12-31 14:37:17', NULL, NULL, NULL),
(26, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 141, '2022-12-31 14:37:18', 0, '2022-12-31 14:37:18', NULL, NULL, NULL),
(27, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 142, '2022-12-31 14:37:19', 0, '2022-12-31 14:37:19', NULL, NULL, NULL),
(28, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 143, '2022-12-31 14:37:19', 0, '2022-12-31 14:37:19', NULL, NULL, NULL),
(29, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 144, '2022-12-31 14:37:19', 0, '2022-12-31 14:37:19', NULL, NULL, NULL),
(30, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 145, '2022-12-31 14:37:20', 0, '2022-12-31 14:37:20', NULL, NULL, NULL),
(31, 1, NULL, 7, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 146, '2022-12-31 14:57:49', 0, '2022-12-31 14:57:49', NULL, NULL, NULL),
(32, 2, NULL, 8, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 106, '2022-12-31 15:00:05', 0, '2022-12-31 15:00:05', NULL, NULL, NULL),
(33, 2, NULL, 8, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 107, '2022-12-31 15:00:15', 0, '2022-12-31 15:00:15', NULL, NULL, NULL),
(34, 2, NULL, NULL, NULL, NULL, 5, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 109, '2022-12-31 15:01:30', 0, '2022-12-31 15:01:30', NULL, NULL, NULL),
(35, 3, NULL, NULL, NULL, 6, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 1, '2023-01-01 04:41:22', 0, '2023-01-01 04:41:22', NULL, NULL, NULL),
(36, 3, NULL, NULL, NULL, 7, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 2, '2023-01-01 04:42:06', 0, '2023-01-01 04:42:06', NULL, NULL, NULL),
(37, 3, NULL, NULL, NULL, 7, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 3, '2023-01-01 04:42:10', 0, '2023-01-01 04:42:10', NULL, NULL, NULL),
(38, 3, NULL, NULL, NULL, 7, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 4, '2023-01-01 04:42:15', 0, '2023-01-01 04:42:15', NULL, NULL, NULL),
(39, 3, NULL, NULL, NULL, 9, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 5, '2023-01-01 04:42:48', 0, '2023-01-01 04:42:48', NULL, NULL, NULL),
(40, 3, NULL, NULL, NULL, 10, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 6, '2023-01-01 04:43:06', 0, '2023-01-01 04:43:06', NULL, NULL, NULL),
(41, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 148, '2023-01-01 06:09:01', 0, '2023-01-01 06:09:01', NULL, NULL, NULL),
(42, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 150, '2023-01-01 06:09:04', 0, '2023-01-01 06:09:04', NULL, NULL, NULL),
(43, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 152, '2023-01-01 06:09:08', 0, '2023-01-01 06:09:08', NULL, NULL, NULL),
(44, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 154, '2023-01-01 06:09:13', 0, '2023-01-01 06:09:13', NULL, NULL, NULL),
(45, 3, NULL, NULL, NULL, NULL, 7, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 8, '2023-01-01 12:11:54', 0, '2023-01-01 12:11:54', NULL, NULL, NULL),
(46, 3, NULL, NULL, NULL, NULL, 7, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 10, '2023-01-01 12:11:58', 0, '2023-01-01 12:11:58', NULL, NULL, NULL),
(47, 1, NULL, NULL, NULL, NULL, 8, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 156, '2023-01-01 13:24:30', 0, '2023-01-01 13:24:30', NULL, NULL, NULL),
(48, 3, NULL, NULL, NULL, NULL, 9, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 12, '2023-01-01 14:20:50', 0, '2023-01-01 14:20:50', NULL, NULL, NULL),
(49, 3, NULL, NULL, NULL, NULL, 9, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 14, '2023-01-01 14:20:57', 0, '2023-01-01 14:20:57', NULL, NULL, NULL),
(50, 3, NULL, NULL, NULL, NULL, 9, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 16, '2023-01-01 14:21:09', 0, '2023-01-01 14:21:09', NULL, NULL, NULL),
(51, 1, 1, NULL, NULL, NULL, NULL, NULL, 'Order product cost', 'Dr.', 1200, -1044, '2023-01-02 12:48:09', 0, '2023-01-02 12:48:09', NULL, NULL, NULL),
(52, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, -1043, '2023-01-09 13:02:54', 0, '2023-01-09 13:02:54', NULL, NULL, NULL),
(53, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, -1042, '2023-01-09 13:03:00', 0, '2023-01-09 13:03:00', NULL, NULL, NULL),
(54, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, -1041, '2023-01-09 13:03:07', 0, '2023-01-09 13:03:07', NULL, NULL, NULL),
(55, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, -1040, '2023-01-09 13:07:01', 0, '2023-01-09 13:07:01', NULL, NULL, NULL),
(56, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 17, '2023-01-09 13:08:14', 0, '2023-01-09 13:08:14', NULL, NULL, NULL),
(57, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 18, '2023-01-09 13:08:19', 0, '2023-01-09 13:08:19', NULL, NULL, NULL),
(58, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 110, '2023-01-09 13:09:33', 0, '2023-01-09 13:09:33', NULL, NULL, NULL),
(59, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 111, '2023-01-09 13:09:36', 0, '2023-01-09 13:09:36', NULL, NULL, NULL),
(60, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 112, '2023-01-09 13:09:42', 0, '2023-01-09 13:09:42', NULL, NULL, NULL),
(61, 1, NULL, NULL, NULL, 13, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1039, '2023-01-14 12:39:02', 0, '2023-01-14 12:39:02', NULL, NULL, NULL),
(62, 1, NULL, NULL, NULL, 14, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1038, '2023-01-14 12:49:25', 0, '2023-01-14 12:49:25', NULL, NULL, NULL),
(63, 2, NULL, NULL, NULL, 15, NULL, NULL, 'Quiz coin get', 'Cr.', 1, 113, '2023-01-14 12:49:52', 0, '2023-01-14 12:49:52', NULL, NULL, NULL),
(64, 1, NULL, NULL, NULL, 16, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1037, '2023-01-14 12:57:45', 0, '2023-01-14 12:57:45', NULL, NULL, NULL),
(65, 1, NULL, NULL, NULL, 16, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1036, '2023-01-14 12:57:49', 0, '2023-01-14 12:57:49', NULL, NULL, NULL),
(66, 1, NULL, NULL, NULL, 16, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1035, '2023-01-14 12:57:51', 0, '2023-01-14 12:57:51', NULL, NULL, NULL),
(67, 1, NULL, NULL, NULL, 18, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1034, '2023-01-15 05:02:24', 0, '2023-01-15 05:02:24', NULL, NULL, NULL),
(68, 1, NULL, NULL, NULL, 18, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1033, '2023-01-15 05:02:35', 0, '2023-01-15 05:02:35', NULL, NULL, NULL),
(69, 1, NULL, NULL, NULL, 19, NULL, NULL, 'Quiz coin get', 'Cr.', 1, -1032, '2023-01-15 13:16:09', 0, '2023-01-15 13:16:09', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `history_user_point`
--

CREATE TABLE `history_user_point` (
  `history_user_point_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `chapter_joined_id` int(11) DEFAULT NULL,
  `mcq_joined_id` int(11) DEFAULT NULL,
  `qe_joined_id` int(11) DEFAULT NULL,
  `voc_mcq_joined_id` int(11) DEFAULT NULL,
  `course_exam_joined_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double UNSIGNED NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_user_point`
--

INSERT INTO `history_user_point` (`history_user_point_id`, `std_id`, `order_id`, `chapter_joined_id`, `mcq_joined_id`, `qe_joined_id`, `voc_mcq_joined_id`, `course_exam_joined_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 2, NULL, NULL, NULL, 1, NULL, NULL, 'Quiz point get', 'Cr.', 1, 1, '2022-12-28 04:37:08', 0, '2022-12-28 04:37:08', NULL, NULL, NULL),
(2, 2, NULL, NULL, NULL, 1, NULL, NULL, 'Quiz point get', 'Cr.', 1, 2, '2022-12-28 04:37:14', 0, '2022-12-28 04:37:14', NULL, NULL, NULL),
(3, 1, NULL, NULL, NULL, 2, NULL, NULL, 'Quiz point get', 'Cr.', 1, 1, '2022-12-28 14:02:47', 0, '2022-12-28 14:02:47', NULL, NULL, NULL),
(4, 1, NULL, NULL, NULL, 2, NULL, NULL, 'Quiz point get', 'Cr.', 1, 2, '2022-12-28 14:02:53', 0, '2022-12-28 14:02:53', NULL, NULL, NULL),
(5, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Quiz point get', 'Cr.', 1, 3, '2022-12-28 14:20:22', 0, '2022-12-28 14:20:22', NULL, NULL, NULL),
(6, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Quiz point get', 'Cr.', 1, 4, '2022-12-28 14:20:25', 0, '2022-12-28 14:20:25', NULL, NULL, NULL),
(7, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Quiz point get', 'Cr.', 1, 5, '2022-12-28 14:20:27', 0, '2022-12-28 14:20:27', NULL, NULL, NULL),
(8, 1, NULL, 4, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 38, '2022-12-29 14:53:54', 0, '2022-12-29 14:53:54', NULL, NULL, NULL),
(9, 1, NULL, 4, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 39, '2022-12-29 14:54:02', 0, '2022-12-29 14:54:02', NULL, NULL, NULL),
(10, 1, NULL, 4, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 40, '2022-12-29 14:54:04', 0, '2022-12-29 14:54:04', NULL, NULL, NULL),
(11, 5, NULL, 5, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 1, '2022-12-31 12:21:18', 0, '2022-12-31 12:21:18', NULL, NULL, NULL),
(12, 5, NULL, 5, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 2, '2022-12-31 12:21:21', 0, '2022-12-31 12:21:21', NULL, NULL, NULL),
(78, 2, NULL, NULL, NULL, 5, NULL, NULL, 'Quiz point get', 'Cr.', 1, 103, '2022-12-31 13:25:53', 0, '2022-12-31 13:25:53', NULL, NULL, NULL),
(79, 2, NULL, NULL, NULL, 5, NULL, NULL, 'Quiz point get', 'Cr.', 1, 104, '2022-12-31 13:26:00', 0, '2022-12-31 13:26:00', NULL, NULL, NULL),
(80, 2, NULL, NULL, NULL, 5, NULL, NULL, 'Quiz point get', 'Cr.', 1, 105, '2022-12-31 13:26:00', 0, '2022-12-31 13:26:00', NULL, NULL, NULL),
(81, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 131, '2022-12-31 14:37:10', 0, '2022-12-31 14:37:10', NULL, NULL, NULL),
(82, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 132, '2022-12-31 14:37:14', 0, '2022-12-31 14:37:14', NULL, NULL, NULL),
(83, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 133, '2022-12-31 14:37:14', 0, '2022-12-31 14:37:14', NULL, NULL, NULL),
(84, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 134, '2022-12-31 14:37:15', 0, '2022-12-31 14:37:15', NULL, NULL, NULL),
(85, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 135, '2022-12-31 14:37:15', 0, '2022-12-31 14:37:15', NULL, NULL, NULL),
(86, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 136, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(87, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 137, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(88, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 138, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(89, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 139, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(90, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 140, '2022-12-31 14:37:16', 0, '2022-12-31 14:37:16', NULL, NULL, NULL),
(91, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 141, '2022-12-31 14:37:17', 0, '2022-12-31 14:37:17', NULL, NULL, NULL),
(92, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 142, '2022-12-31 14:37:19', 0, '2022-12-31 14:37:19', NULL, NULL, NULL),
(93, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 143, '2022-12-31 14:37:19', 0, '2022-12-31 14:37:19', NULL, NULL, NULL),
(94, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 144, '2022-12-31 14:37:19', 0, '2022-12-31 14:37:19', NULL, NULL, NULL),
(95, 1, NULL, 6, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 145, '2022-12-31 14:37:20', 0, '2022-12-31 14:37:20', NULL, NULL, NULL),
(96, 1, NULL, 7, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 146, '2022-12-31 14:57:49', 0, '2022-12-31 14:57:49', NULL, NULL, NULL),
(97, 2, NULL, 8, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 106, '2022-12-31 15:00:05', 0, '2022-12-31 15:00:05', NULL, NULL, NULL),
(98, 2, NULL, 8, NULL, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 107, '2022-12-31 15:00:15', 0, '2022-12-31 15:00:15', NULL, NULL, NULL),
(99, 2, NULL, NULL, NULL, NULL, 5, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 109, '2022-12-31 15:01:30', 0, '2022-12-31 15:01:30', NULL, NULL, NULL),
(100, 3, NULL, NULL, NULL, 6, NULL, NULL, 'Quiz point get', 'Cr.', 1, 1, '2023-01-01 04:41:22', 0, '2023-01-01 04:41:22', NULL, NULL, NULL),
(101, 3, NULL, NULL, NULL, 7, NULL, NULL, 'Quiz point get', 'Cr.', 1, 2, '2023-01-01 04:42:06', 0, '2023-01-01 04:42:06', NULL, NULL, NULL),
(102, 3, NULL, NULL, NULL, 7, NULL, NULL, 'Quiz point get', 'Cr.', 1, 3, '2023-01-01 04:42:10', 0, '2023-01-01 04:42:10', NULL, NULL, NULL),
(103, 3, NULL, NULL, NULL, 7, NULL, NULL, 'Quiz point get', 'Cr.', 1, 4, '2023-01-01 04:42:15', 0, '2023-01-01 04:42:15', NULL, NULL, NULL),
(104, 3, NULL, NULL, NULL, 9, NULL, NULL, 'Quiz point get', 'Cr.', 1, 5, '2023-01-01 04:42:48', 0, '2023-01-01 04:42:48', NULL, NULL, NULL),
(105, 3, NULL, NULL, NULL, 10, NULL, NULL, 'Quiz point get', 'Cr.', 1, 6, '2023-01-01 04:43:06', 0, '2023-01-01 04:43:06', NULL, NULL, NULL),
(106, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 148, '2023-01-01 06:09:01', 0, '2023-01-01 06:09:01', NULL, NULL, NULL),
(107, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 150, '2023-01-01 06:09:04', 0, '2023-01-01 06:09:04', NULL, NULL, NULL),
(108, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 152, '2023-01-01 06:09:08', 0, '2023-01-01 06:09:08', NULL, NULL, NULL),
(109, 1, NULL, NULL, NULL, NULL, 6, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 154, '2023-01-01 06:09:13', 0, '2023-01-01 06:09:13', NULL, NULL, NULL),
(110, 3, NULL, NULL, NULL, NULL, 7, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 8, '2023-01-01 12:11:54', 0, '2023-01-01 12:11:54', NULL, NULL, NULL),
(111, 3, NULL, NULL, NULL, NULL, 7, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 10, '2023-01-01 12:11:58', 0, '2023-01-01 12:11:58', NULL, NULL, NULL),
(112, 1, NULL, NULL, NULL, NULL, 8, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 156, '2023-01-01 13:24:30', 0, '2023-01-01 13:24:30', NULL, NULL, NULL),
(113, 3, NULL, NULL, NULL, NULL, 9, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 12, '2023-01-01 14:20:50', 0, '2023-01-01 14:20:50', NULL, NULL, NULL),
(114, 3, NULL, NULL, NULL, NULL, 9, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 14, '2023-01-01 14:20:57', 0, '2023-01-01 14:20:57', NULL, NULL, NULL),
(115, 3, NULL, NULL, NULL, NULL, 9, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 16, '2023-01-01 14:21:09', 0, '2023-01-01 14:21:09', NULL, NULL, NULL),
(116, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 157, '2023-01-09 13:02:54', 0, '2023-01-09 13:02:54', NULL, NULL, NULL),
(117, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 158, '2023-01-09 13:03:00', 0, '2023-01-09 13:03:00', NULL, NULL, NULL),
(118, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 159, '2023-01-09 13:03:07', 0, '2023-01-09 13:03:07', NULL, NULL, NULL),
(119, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 160, '2023-01-09 13:07:01', 0, '2023-01-09 13:07:01', NULL, NULL, NULL),
(120, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 17, '2023-01-09 13:08:14', 0, '2023-01-09 13:08:14', NULL, NULL, NULL),
(121, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 18, '2023-01-09 13:08:19', 0, '2023-01-09 13:08:19', NULL, NULL, NULL),
(122, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 110, '2023-01-09 13:09:33', 0, '2023-01-09 13:09:33', NULL, NULL, NULL),
(123, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 111, '2023-01-09 13:09:36', 0, '2023-01-09 13:09:36', NULL, NULL, NULL),
(124, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'Course quiz point get', 'Cr.', 1, 112, '2023-01-09 13:09:42', 0, '2023-01-09 13:09:42', NULL, NULL, NULL),
(125, 1, NULL, NULL, NULL, 13, NULL, NULL, 'Quiz point get', 'Cr.', 1, 161, '2023-01-14 12:39:01', 0, '2023-01-14 12:39:01', NULL, NULL, NULL),
(126, 1, NULL, NULL, NULL, 14, NULL, NULL, 'Quiz point get', 'Cr.', 1, 162, '2023-01-14 12:49:25', 0, '2023-01-14 12:49:25', NULL, NULL, NULL),
(127, 2, NULL, NULL, NULL, 15, NULL, NULL, 'Quiz point get', 'Cr.', 1, 113, '2023-01-14 12:49:52', 0, '2023-01-14 12:49:52', NULL, NULL, NULL),
(128, 1, NULL, NULL, NULL, 16, NULL, NULL, 'Quiz point get', 'Cr.', 1, 163, '2023-01-14 12:57:45', 0, '2023-01-14 12:57:45', NULL, NULL, NULL),
(129, 1, NULL, NULL, NULL, 16, NULL, NULL, 'Quiz point get', 'Cr.', 1, 164, '2023-01-14 12:57:49', 0, '2023-01-14 12:57:49', NULL, NULL, NULL),
(130, 1, NULL, NULL, NULL, 16, NULL, NULL, 'Quiz point get', 'Cr.', 1, 165, '2023-01-14 12:57:51', 0, '2023-01-14 12:57:51', NULL, NULL, NULL),
(131, 1, NULL, NULL, NULL, 18, NULL, NULL, 'Quiz point get', 'Cr.', 1, 166, '2023-01-15 05:02:24', 0, '2023-01-15 05:02:24', NULL, NULL, NULL),
(132, 1, NULL, NULL, NULL, 18, NULL, NULL, 'Quiz point get', 'Cr.', 1, 167, '2023-01-15 05:02:35', 0, '2023-01-15 05:02:35', NULL, NULL, NULL),
(133, 1, NULL, NULL, NULL, 19, NULL, NULL, 'Quiz point get', 'Cr.', 1, 168, '2023-01-15 13:16:09', 0, '2023-01-15 13:16:09', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mcq_exam_joined`
--

CREATE TABLE `mcq_exam_joined` (
  `mcq_joined_id` int(11) NOT NULL,
  `skill_video_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) UNSIGNED DEFAULT NULL,
  `incorrect_answers` int(11) UNSIGNED DEFAULT NULL,
  `earn_points` int(11) UNSIGNED DEFAULT NULL,
  `earn_coins` int(11) UNSIGNED DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `notice_id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`notice_id`, `title`, `description`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Assalamuyakom', '<div>kese ho app look</div>', 1, '2023-01-10 18:59:43', NULL, NULL, NULL, NULL),
(2, 'Sumon vai ', '<div>Sumon vai valo lok, joyer mala tari hok...</div>', 1, '2023-01-10 19:01:09', NULL, NULL, NULL, NULL),
(3, 'fiil the gap', 'ngjbv<div><table class=\"table-1\"><tbody><tr><td> </td><td> </td><td> </td><td> </td><td> </td></tr><tr><td> </td><td> </td><td> </td><td> </td><td> </td></tr><tr><td> </td><td> </td><td> </td><td> </td><td> </td></tr></tbody></table><br></div>', 1, '2023-01-10 19:01:37', NULL, NULL, NULL, NULL),
(4, 'Tomorrow our app will be down for 2 hours', '<div>Tomorrow our app will be down for 2 hours for Maintenance.<br></div>', 1, '2023-01-10 19:02:11', NULL, NULL, NULL, NULL),
(5, 'Notice for Munna Vai', '<div>Cha kaben nah 3 3</div>', 1, '2023-01-10 19:02:40', NULL, NULL, NULL, NULL),
(6, 'efds', '<div>fdvbdbd dh dfh ddf h</div>', 1, '2023-01-11 11:23:32', NULL, NULL, NULL, NULL),
(7, 'Shob free!', '<div>Tk lagbe na mal niye jaan...</div>', 1, '2023-01-12 20:47:17', NULL, NULL, NULL, NULL),
(8, 'জরুরী বিজ্ঞপ্তি', '<div>আগামীকাল এ্যাপ সাময়িক বন্ধ থাকবে</div>', 1, '2023-01-21 20:52:32', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notice_send`
--

CREATE TABLE `notice_send` (
  `send_notice_id` int(11) NOT NULL,
  `notice_id` int(11) NOT NULL,
  `receiver_std_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_send`
--

INSERT INTO `notice_send` (`send_notice_id`, `notice_id`, `receiver_std_id`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(4, 1, 4, 1, '2023-01-10 18:59:43', NULL, NULL, NULL, NULL),
(9, 2, 4, 1, '2023-01-10 19:01:10', NULL, NULL, NULL, NULL),
(14, 3, 4, 1, '2023-01-10 19:01:37', NULL, NULL, NULL, NULL),
(19, 4, 4, 1, '2023-01-10 19:02:12', NULL, NULL, NULL, NULL),
(24, 5, 4, 1, '2023-01-10 19:02:40', NULL, NULL, NULL, NULL),
(25, 5, 5, 1, '2023-01-10 19:02:40', NULL, NULL, NULL, NULL),
(28, 6, 3, 1, '2023-01-11 11:23:32', NULL, NULL, NULL, NULL),
(29, 6, 4, 1, '2023-01-11 11:23:32', NULL, NULL, NULL, NULL),
(30, 6, 5, 1, '2023-01-11 11:23:32', NULL, NULL, NULL, NULL),
(33, 7, 3, 1, '2023-01-12 20:47:17', NULL, NULL, NULL, NULL),
(34, 7, 4, 1, '2023-01-12 20:47:17', NULL, NULL, NULL, NULL),
(35, 7, 5, 1, '2023-01-12 20:47:17', NULL, NULL, NULL, NULL),
(36, 8, 1, 1, '2023-01-21 20:52:32', NULL, NULL, NULL, NULL),
(38, 8, 3, 1, '2023-01-21 20:52:32', NULL, NULL, NULL, NULL),
(39, 8, 4, 1, '2023-01-21 20:52:32', NULL, NULL, NULL, NULL),
(40, 8, 5, 1, '2023-01-21 20:52:32', NULL, NULL, NULL, NULL),
(41, 8, 6, 1, '2023-01-21 20:52:32', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `pymnt_method_id` int(11) DEFAULT NULL,
  `amount` double UNSIGNED NOT NULL,
  `entire_sale_discount` int(11) UNSIGNED DEFAULT NULL,
  `vat` int(11) UNSIGNED DEFAULT NULL,
  `delivery_charge` int(11) UNSIGNED DEFAULT NULL,
  `final_amount` double UNSIGNED NOT NULL,
  `global_address_id` int(11) NOT NULL,
  `status` enum('1','0','2','3') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '2=pandding,0=unpaid,1=paid,3=cancel',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `year` longtext COLLATE utf8_unicode_ci,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `std_id`, `pymnt_method_id`, `amount`, `entire_sale_discount`, `vat`, `delivery_charge`, `final_amount`, `global_address_id`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 1200, NULL, NULL, NULL, 1200, 0, '0', '2023-01-02 12:48:09', NULL, '2023-01-02 18:48:09', 1, NULL, '2023-01-02 20:18:20', NULL, NULL),
(2, 1, 2, 3192, NULL, NULL, NULL, 3192, 0, '0', '2023-01-02 14:10:03', NULL, '2023-01-02 20:10:03', 1, NULL, '2023-01-02 20:18:01', NULL, NULL),
(3, 2, 2, 10032, NULL, NULL, NULL, 10032, 0, '0', '2023-01-02 14:13:26', NULL, '2023-01-02 20:13:26', 2, NULL, '2023-01-02 20:18:13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `price` double UNSIGNED NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `total_price` double UNSIGNED NOT NULL,
  `discount` int(11) UNSIGNED DEFAULT NULL,
  `final_price` double UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) UNSIGNED DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `order_id`, `prod_id`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 1200, 1, 1200, NULL, 1200, '2023-01-02 18:48:09', 1, NULL, '2023-01-02 18:48:09', NULL, NULL),
(2, 2, 2, 228, 14, 3192, NULL, 3192, '2023-01-02 20:10:04', 1, NULL, '2023-01-02 20:10:04', NULL, NULL),
(3, 3, 2, 228, 44, 10032, NULL, 10032, '2023-01-02 20:13:26', 2, NULL, '2023-01-02 20:13:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `std_id` int(11) DEFAULT NULL,
  `course_subscribe_id` int(11) DEFAULT NULL,
  `class_subscribe_id` int(11) DEFAULT NULL,
  `amount_original` float NOT NULL,
  `aam_service_charge` float NOT NULL,
  `store_amount` float NOT NULL,
  `pay_status` varchar(50) NOT NULL,
  `aam_txnid` varchar(155) NOT NULL,
  `mer_txnid` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `std_id`, `course_subscribe_id`, `class_subscribe_id`, `amount_original`, `aam_service_charge`, `store_amount`, `pay_status`, `aam_txnid`, `mer_txnid`) VALUES
(27, 2, NULL, NULL, 50, 0, 48.37, 'Failed', 'AAM1672490912103409', 'iqraw_154672342556'),
(28, 2, NULL, 16, 50, 1.63, 48.37, 'Successful', 'AAM1672490993103744', 'iqraw_687338645592'),
(29, 1, NULL, NULL, 200, 0, 193.5, 'Failed', 'AAM1672491202103960', 'iqraw_628000014819'),
(30, 1, NULL, 17, 200, 6.5, 193.5, 'Successful', 'AAM1672491220103088', 'iqraw_341974787828'),
(31, 5, 12, NULL, 88, 1.85, 86.15, 'Successful', 'AAM1672491234103035', 'iqraw_261449990106'),
(32, 2, NULL, NULL, 88, 0, 85.14, 'Failed', 'AAM1672491422103697', 'iqraw_623424596775'),
(33, 2, 13, NULL, 88, 2.86, 85.14, 'Successful', 'AAM1672491470103872', 'iqraw_197024568860'),
(34, 4, 14, NULL, 1, 0.02, 0.98, 'Successful', 'AAM1672495481103460', 'iqraw_636368082557'),
(35, 1, 15, NULL, 1, 0.02, 0.98, 'Successful', 'AAM1672495480103242', 'iqraw_803017011719'),
(36, 1, 16, NULL, 88, 1.85, 86.15, 'Successful', 'AAM1672495609103957', 'iqraw_643224671269'),
(37, 1, 17, NULL, 1, 0.02, 0.98, 'Successful', 'AAM1672496846103986', 'iqraw_687298961935'),
(38, 1, 18, NULL, 1, 0.02, 0.98, 'Successful', 'AAM1672497089103183', 'iqraw_919675877130'),
(39, 1, NULL, 18, 50, 1.63, 48.37, 'Successful', 'AAM1672497409103913', 'iqraw_115388077020'),
(40, 1, 19, NULL, 2, 0.07, 1.93, 'Successful', 'AAM1672549785103773', 'iqraw_614529126298'),
(41, 1, NULL, NULL, 1, 0, 0.98, 'Failed', 'AAM1672549951103765', 'iqraw_614873544328'),
(42, 1, NULL, 19, 1, 0.04, 0.96, 'Successful', 'AAM1672549962103950', 'iqraw_708780700964'),
(43, 1, NULL, NULL, 1, 0, 0.98, 'Failed', 'AAM1672550028103902', 'iqraw_282293254551'),
(44, 1, NULL, 20, 1, 0.02, 0.98, 'Successful', 'AAM1672550047103963', 'iqraw_153671023327'),
(45, 2, NULL, NULL, 20, 0, 19.58, 'Failed', 'AAM1672553188103671', 'iqraw_873886660181'),
(46, 2, 20, NULL, 20, 0.42, 19.58, 'Successful', 'AAM1672553393103146', 'iqraw_772471672322'),
(47, 1, 21, NULL, 20, 0.65, 19.35, 'Successful', 'AAM1672554238103898', 'iqraw_775602954883'),
(48, 3, NULL, 21, 1, 0.02, 0.98, 'Successful', 'AAM1672576055185891', 'iqraw_554815346221'),
(49, 3, NULL, 22, 25, 0.88, 24.12, 'Successful', 'AAM1672576316185989', 'iqraw_626420254860'),
(50, 3, NULL, 23, 50, 1.63, 48.37, 'Successful', 'AAM1672578622185260', 'iqraw_287594759430'),
(51, 4, NULL, 24, 200, 6.5, 193.5, 'Successful', 'AAM1672749563103577', 'iqraw_191540843138'),
(52, 1, 22, NULL, 10, 0.33, 9.67, 'Successful', 'AAM1673097599103457', 'iqraw_391708136325'),
(53, 1, NULL, 25, 1, 0.02, 0.98, 'Successful', 'AAM1673102014103912', 'iqraw_637323555963'),
(54, 4, 23, NULL, 35, 1.14, 33.86, 'Successful', 'AAM1673161821103356', 'iqraw_446073653584'),
(55, 2, 24, NULL, 20, 0.4, 19.6, 'Successful', 'AAM1673267260103917', 'iqraw_687484250803'),
(56, 1, 25, NULL, 20, 0.65, 19.35, 'Successful', 'AAM1673269264103533', 'iqraw_533618842744'),
(57, 3, 26, NULL, 20, 0.7, 19.3, 'Successful', 'AAM1673269590185535', 'iqraw_291248478774'),
(58, 6, 27, NULL, 88, 3.08, 84.92, 'Successful', 'AAM1674657866103865', 'iqraw_762338643815'),
(59, 5, NULL, 27, 25, 0.53, 24.47, 'Successful', 'AAM1676261928103215', 'iqraw_513799505573');

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `pymnt_method_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `icon` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`pymnt_method_id`, `type_name`, `icon`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Coin', '', 1, '2022-08-08 18:43:27', NULL, '2022-12-26 10:37:42', NULL, NULL),
(2, 'Bkash', '', 1, '2022-08-13 12:23:44', NULL, '2022-08-13 12:23:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `name` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `price` int(11) UNSIGNED NOT NULL,
  `unit` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `picture` varchar(155) DEFAULT NULL,
  `prod_cat_id` int(11) DEFAULT NULL,
  `product_type` enum('1','2') NOT NULL DEFAULT '1',
  `gender_type` enum('Man','Women','Both') NOT NULL DEFAULT 'Both',
  `description` text,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `store_id`, `name`, `quantity`, `price`, `unit`, `brand_id`, `picture`, `prod_cat_id`, `product_type`, `gender_type`, `description`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 1, 'Nike', 1, 1200, 1, 2, 'pro_1672584269_236d89d174fee368d517.png', 3, '1', 'Man', '', '1', '2023-01-01 14:44:29', 0, '2023-01-02 12:48:09', NULL, NULL, NULL),
(2, 1, 'Keepall', 0, 228, 1, 1, 'pro_1672584415_93cadebe3ed143130a43.jpg', 3, '1', 'Man', '<div>New</div>', '1', '2023-01-01 14:46:55', 0, '2023-01-02 14:10:03', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `prod_cat_id` int(11) NOT NULL,
  `parent_pro_cat_id` int(11) NOT NULL,
  `product_category` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`prod_cat_id`, `parent_pro_cat_id`, `product_category`, `image`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 0, 'Bag', NULL, '1', '2023-01-01 19:06:07', 1, '2023-01-01 19:06:07', NULL, NULL, NULL),
(2, 0, 'Shoes', NULL, '1', '2023-01-01 20:24:34', 1, '2023-01-01 20:24:34', NULL, NULL, NULL),
(3, 2, 'Men Shoes', NULL, '1', '2023-01-01 20:25:27', 1, '2023-01-01 20:25:27', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_info`
--

CREATE TABLE `quiz_exam_info` (
  `quiz_exam_info_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `quiz_name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `total_questions` int(11) UNSIGNED DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) UNSIGNED DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_exam_info`
--

INSERT INTO `quiz_exam_info` (`quiz_exam_info_id`, `class_id`, `subject_id`, `quiz_name`, `total_questions`, `published_date`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 'Test 11', 2, '2023-01-12', '1', 1, '2022-12-26 20:07:05', NULL, '2023-01-12 21:00:24', NULL, NULL),
(2, 1, 2, 'Fill in the words', 5, '2022-12-27', '1', 1, '2022-12-27 20:23:56', NULL, '2022-12-28 19:24:10', NULL, NULL),
(3, 2, 4, 'BGFFFF', 2, '2022-12-28', '1', 1, '2022-12-28 19:03:56', NULL, '2023-01-01 19:17:23', NULL, NULL),
(4, 1, 3, 'afafafafa', 1, '2022-12-29', '1', 1, '2022-12-28 19:22:02', NULL, '2022-12-28 19:23:19', NULL, NULL),
(5, 1, 1, '2', 1, '2022-12-28', '1', 1, '2022-12-28 20:07:07', NULL, '2022-12-28 20:07:07', NULL, NULL),
(6, 1, 3, 'Math 1', 3, '2022-12-29', '1', 1, '2022-12-28 20:17:53', NULL, '2022-12-29 19:08:42', NULL, NULL),
(7, 2, 4, 'New chap', 2, '2022-12-28', '1', 1, '2022-12-28 20:19:36', NULL, '2022-12-28 20:22:30', NULL, NULL),
(9, 1, 3, 'Multiplication', 6, '2022-12-29', '1', 1, '2022-12-28 20:24:07', NULL, '2022-12-29 19:08:17', NULL, NULL),
(10, 2, 4, 'New 1st Chap', 2, '2022-12-31', '1', 1, '2022-12-31 20:30:49', NULL, '2022-12-31 20:30:49', NULL, NULL),
(11, 9, 26, 'ABC', 5, '2023-01-12', '1', 4, '2023-01-01 11:17:02', NULL, '2023-01-12 20:56:50', NULL, NULL),
(12, 9, 25, 'Bangla', 3, '2023-01-01', '1', 1, '2023-01-01 11:19:15', NULL, '2023-01-01 11:19:15', NULL, NULL),
(13, 9, 27, 'plus Minus', 4, '2023-01-01', '1', 1, '2023-01-01 11:19:58', NULL, '2023-01-01 11:19:58', NULL, NULL),
(14, 9, 25, 'Bangla exam 2', 2, '2023-01-01', '1', 1, '2023-01-01 11:21:06', NULL, '2023-01-01 11:21:06', NULL, NULL),
(15, 8, 24, 'Math eq.', 2, '2023-01-05', '1', 1, '2023-01-05 20:39:26', NULL, '2023-01-05 20:39:26', NULL, NULL),
(16, 5, 14, 'ABCD', 5, '2023-01-15', '1', 1, '2023-01-14 18:22:08', NULL, '2023-01-15 11:00:54', NULL, NULL),
(17, 9, 36, 'afafafafa', 5, '2023-01-14', '1', 4, '2023-01-14 18:55:19', NULL, '2023-01-14 18:55:19', NULL, NULL),
(18, 5, 15, 'Janu 1', 2, '2023-01-14', '1', 1, '2023-01-14 18:56:48', NULL, '2023-01-14 18:56:48', NULL, NULL),
(19, 3, 9, 'count up', 5, '2023-01-13', '1', 1, '2023-01-15 11:05:48', NULL, '2023-01-15 11:05:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_joined`
--

CREATE TABLE `quiz_exam_joined` (
  `qe_joined_id` int(11) NOT NULL,
  `quiz_exam_info_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) UNSIGNED DEFAULT NULL,
  `incorrect_answers` int(11) UNSIGNED DEFAULT NULL,
  `earn_points` int(11) UNSIGNED DEFAULT NULL,
  `earn_coins` int(11) UNSIGNED DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_exam_joined`
--

INSERT INTO `quiz_exam_joined` (`qe_joined_id`, `quiz_exam_info_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 2, 2, NULL, 2, 2, 2, '2022-12-28 10:36:43', NULL, '2022-12-28 10:37:14', NULL, NULL),
(2, 2, 1, 2, NULL, 2, 2, 1, '2022-12-28 19:24:33', NULL, '2022-12-28 20:02:53', NULL, NULL),
(3, 3, 2, NULL, NULL, NULL, NULL, 2, '2022-12-28 20:18:43', NULL, '2022-12-28 20:18:43', NULL, NULL),
(4, 6, 1, 3, NULL, 3, 3, 1, '2022-12-28 20:20:18', NULL, '2022-12-28 20:20:27', NULL, NULL),
(5, 7, 2, 3, NULL, 3, 3, 2, '2022-12-31 19:25:42', NULL, '2022-12-31 19:26:00', NULL, NULL),
(6, 4, 3, 1, NULL, 1, 1, 3, '2023-01-01 10:41:14', NULL, '2023-01-01 10:41:22', NULL, NULL),
(7, 6, 3, 3, NULL, 3, 3, 3, '2023-01-01 10:41:55', NULL, '2023-01-01 10:42:15', NULL, NULL),
(8, 9, 3, NULL, NULL, NULL, NULL, 3, '2023-01-01 10:42:32', NULL, '2023-01-01 10:42:32', NULL, NULL),
(9, 5, 3, 1, NULL, 1, 1, 3, '2023-01-01 10:42:44', NULL, '2023-01-01 10:42:48', NULL, NULL),
(10, 1, 3, 1, 1, 1, 1, 3, '2023-01-01 10:42:58', NULL, '2023-01-01 10:43:14', NULL, NULL),
(11, 11, 1, NULL, NULL, NULL, NULL, 1, '2023-01-01 11:18:06', NULL, '2023-01-01 11:18:06', NULL, NULL),
(12, 1, 6, NULL, NULL, NULL, NULL, 6, '2023-01-12 20:59:03', NULL, '2023-01-12 20:59:03', NULL, NULL),
(13, 13, 1, 1, NULL, 1, 1, 1, '2023-01-14 18:38:47', NULL, '2023-01-14 18:39:01', NULL, NULL),
(14, 16, 1, 1, NULL, 1, 1, 1, '2023-01-14 18:48:53', NULL, '2023-01-14 18:49:25', NULL, NULL),
(15, 16, 2, 1, NULL, 1, 1, 2, '2023-01-14 18:49:05', NULL, '2023-01-14 18:49:52', NULL, NULL),
(16, 12, 1, 3, NULL, 3, 3, 1, '2023-01-14 18:57:42', NULL, '2023-01-14 18:57:51', NULL, NULL),
(17, 14, 1, NULL, NULL, NULL, NULL, 1, '2023-01-14 18:57:56', NULL, '2023-01-14 18:57:56', NULL, NULL),
(18, 17, 1, 2, 2, 2, 2, 1, '2023-01-15 11:02:21', NULL, '2023-01-15 11:02:38', NULL, NULL),
(19, 19, 1, 1, NULL, 1, 1, 1, '2023-01-15 19:16:06', NULL, '2023-01-15 19:16:09', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_questions`
--

CREATE TABLE `quiz_exam_questions` (
  `quiz_question_id` int(11) NOT NULL,
  `quiz_exam_info_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_exam_questions`
--

INSERT INTO `quiz_exam_questions` (`quiz_question_id`, `quiz_exam_info_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'আতা গাছে কী পাখি?', 'তোতা', 'কাক', 'কোকিল', 'ময়না', 'one', '1', 1, '2022-12-26 20:09:58', NULL, '2022-12-26 20:09:58', NULL, NULL),
(2, 1, 'ডালিম গাছে কী আছে?', 'বৌ', 'মৌ', 'কৌ', 'রৌ', 'two', '1', 1, '2022-12-26 20:10:21', NULL, '2022-12-26 20:10:21', NULL, NULL),
(3, 2, 'APP_E', 'i', 'j', 'k', 'l', 'four', '1', 1, '2022-12-27 20:31:02', NULL, '2022-12-27 20:33:18', NULL, NULL),
(4, 2, 'Man_o ', 'g', 'h', 'i', 'j', 'one', '1', 1, '2022-12-27 20:32:45', NULL, '2022-12-27 20:32:45', NULL, NULL),
(7, 4, '1', '1', '2', '3', '4', 'one', '1', 1, '2022-12-28 19:22:44', NULL, '2022-12-28 19:22:44', NULL, NULL),
(8, 5, '2', '1', '2', '3', '4', 'two', '1', 1, '2022-12-28 20:07:54', NULL, '2022-12-28 20:07:54', NULL, NULL),
(9, 6, '1', '1', '2', '3', '4', 'one', '1', 1, '2022-12-28 20:19:12', NULL, '2022-12-28 20:19:12', NULL, NULL),
(10, 6, '2', '1', '2', '3', '4', 'two', '1', 1, '2022-12-28 20:19:32', NULL, '2022-12-28 20:19:32', NULL, NULL),
(11, 6, '4', '1', '2', '4', '3', 'three', '1', 1, '2022-12-28 20:19:53', NULL, '2022-12-28 20:19:53', NULL, NULL),
(12, 7, 'বাড়ির কাজে আমরা কী করি?', 'হেলা', 'বকাঝকা', 'সাহায্য', 'সাহায্য করি না', 'three', '1', 1, '2022-12-28 20:21:19', NULL, '2022-12-28 20:21:19', NULL, NULL),
(13, 7, 'আতা গাছে কী পাখি?', 'তোতা', 'কাক', 'কোকিল', 'ময়না', 'one', '1', 1, '2022-12-28 20:21:57', NULL, '2022-12-28 20:21:57', NULL, NULL),
(14, 10, 'আতা গাছে কী পাখি?', 'তোতা', 'কাক', 'কৌ', 'রৌ', 'one', '1', 1, '2022-12-31 20:33:35', NULL, '2022-12-31 20:33:35', NULL, NULL),
(15, 10, 'ডালিম গাছে কী আছে?', 'বৌ', 'মৌ', 'কোকিল', 'ময়না', 'two', '1', 1, '2022-12-31 20:34:13', NULL, '2022-12-31 20:34:13', NULL, NULL),
(16, 12, '2', '1', '2', '3', '4', 'two', '1', 1, '2023-01-01 11:19:40', NULL, '2023-01-01 11:19:40', NULL, NULL),
(17, 12, '4', '1', '2', '3', '4', 'four', '1', 1, '2023-01-01 11:20:03', NULL, '2023-01-01 11:20:03', NULL, NULL),
(18, 12, '1', '1', '2', '3', '4', 'one', '1', 1, '2023-01-01 11:20:16', NULL, '2023-01-01 11:20:16', NULL, NULL),
(19, 13, '10-5+6+9-7=?', '26', '13', '16', '17', 'two', '1', 1, '2023-01-01 11:24:35', NULL, '2023-01-01 11:24:35', NULL, NULL),
(20, 16, 'What is the name of the capital of America?', 'Chikago', 'New York', 'Atlanta', 'Toronto', 'two', '1', 1, '2023-01-14 18:35:43', NULL, '2023-01-14 18:35:43', NULL, NULL),
(21, 17, '5', '1', '2', '3', 'E', 'four', '1', 4, '2023-01-14 18:56:02', NULL, '2023-01-14 18:56:02', NULL, NULL),
(22, 17, '1+1', '2', '3', '9', '10', 'four', '1', 4, '2023-01-14 18:56:30', NULL, '2023-01-14 18:56:30', NULL, NULL),
(23, 17, '2', '2', '2', '2', '2', 'two', '1', 4, '2023-01-14 18:56:49', NULL, '2023-01-14 18:56:49', NULL, NULL),
(24, 17, '234124', '1', '1', '1', '1', 'one', '1', 4, '2023-01-14 18:57:04', NULL, '2023-01-14 18:57:04', NULL, NULL),
(25, 18, '5+2=?', '6', '7', '8', '9', 'two', '1', 1, '2023-01-14 18:57:36', NULL, '2023-01-14 18:57:36', NULL, NULL),
(26, 18, '10-5=?', '4', '5', '6', '7', 'two', '1', 1, '2023-01-14 18:58:13', NULL, '2023-01-14 18:58:13', NULL, NULL),
(27, 19, '2 x 6 + 4 + 7 -7=?', '21', '19', '16', '26', 'three', '1', 1, '2023-01-15 11:13:07', NULL, '2023-01-15 11:13:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `permission` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedby` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role`, `permission`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Student\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User_roll\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Quiz_question\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary_exam\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Store\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"ProductCategory\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Order\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class_group\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Subscribe\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class_subscribe_package\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class_subscribe\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Notice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', 1, '2022-06-26 13:05:05', NULL, '2023-01-10 18:56:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` text,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`settings_id`, `label`, `value`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'points_chapter_mcq', '1', 1, '2022-06-13 11:51:50', NULL, '2022-06-19 18:45:14', NULL, NULL),
(2, 'points_semister_mcq', '1', 1, '2022-06-13 11:52:49', NULL, '2022-06-13 11:52:49', NULL, NULL),
(3, 'points_vocabulary_mcq', '2', 1, '2022-06-13 11:53:50', NULL, '2022-07-28 18:23:40', NULL, NULL),
(7, 'points_video_mcq', '1', 1, '2022-07-19 09:59:40', NULL, '2022-07-19 09:59:40', NULL, NULL),
(8, 'vocabulary_quiz_view_frontEnd', '5', 1, '2022-07-26 12:57:41', NULL, '2023-01-03 19:50:04', NULL, NULL),
(9, 'points_course_mcq', '1', 1, '2023-01-08 19:19:45', NULL, '2023-01-08 19:19:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_questions`
--

CREATE TABLE `skill_questions` (
  `skill_question_id` int(11) NOT NULL,
  `skill_video_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skill_questions`
--

INSERT INTO `skill_questions` (`skill_question_id`, `skill_video_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'What is MS Excel?', 'a', 'b', 'c', 'd', 'two', '1', 1, '2023-01-01 20:34:45', NULL, '2023-01-01 20:34:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_subject`
--

CREATE TABLE `skill_subject` (
  `skill_subject_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skill_subject`
--

INSERT INTO `skill_subject` (`skill_subject_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'MS Excel', '1', 1, '2023-01-01 20:30:06', NULL, '2023-01-01 20:30:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_video`
--

CREATE TABLE `skill_video` (
  `skill_video_id` int(11) NOT NULL,
  `skill_subject_id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `thumb` text,
  `author` varchar(155) NOT NULL,
  `total_views` int(11) UNSIGNED NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skill_video`
--

INSERT INTO `skill_video` (`skill_video_id`, `skill_subject_id`, `title`, `URL`, `thumb`, `author`, `total_views`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'Most SPECTACULAR SKILLS of the Year 2022', 'VEIJ1m5qTXM', 'thumb_1672583541_2f2914c1d1c7b7abd6af.jpg', 'Admin', 0, '1', 1, '2023-01-01 20:32:22', NULL, '2023-01-01 20:32:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `store_id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `quantity` int(11) UNSIGNED DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `purchase_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Last purchase price will be added here.',
  `is_default` enum('0','1') NOT NULL DEFAULT '0',
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) DEFAULT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`store_id`, `name`, `prod_id`, `quantity`, `unit`, `purchase_date`, `is_default`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 'Bag', NULL, NULL, NULL, '2023-01-01 19:05:34', '0', '2023-01-01 13:05:34', NULL, '2023-01-01 13:05:34', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `std_id` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `father_name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `address_2` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `school_name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Unisex') DEFAULT NULL,
  `religion` enum('Islam','Hindu','Christian','Buddhism') DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `class_id` int(5) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `institute` enum('School','Madrasha') NOT NULL DEFAULT 'School',
  `pic` varchar(100) NOT NULL,
  `point` int(11) DEFAULT NULL,
  `coin` int(11) DEFAULT NULL,
  `badge_id` int(11) DEFAULT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`std_id`, `phone`, `password`, `name`, `father_name`, `address`, `address_2`, `city`, `state`, `postcode`, `country`, `school_name`, `gender`, `religion`, `age`, `class_id`, `class_group_id`, `institute`, `pic`, `point`, `coin`, `badge_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1400060877, '7c222fb2927d828af22f592134e8932480637c0d', 'AB ', 'MZ', 'nowapara, jeshore, bangladesh', NULL, NULL, NULL, NULL, NULL, '', 'Male', 'Islam', 10, 3, NULL, 'School', 'pro_1672496539_74a96ad63bfd7083a854.jpeg', 168, -1032, NULL, '1', 1, '2022-12-26 18:30:44', NULL, '2023-01-15 19:16:09', NULL, NULL),
(2, 1929649448, '7c222fb2927d828af22f592134e8932480637c0d', 'MD. TARIQUL ISLAM', 'MD. SHARIFUL ISLAM', 'Noapara', NULL, NULL, NULL, NULL, NULL, 'Shankarpasha', 'Male', 'Islam', 6, 9, 2, 'School', '', 113, 113, NULL, '1', 1, '2022-12-26 18:47:24', NULL, '2023-01-14 19:00:31', NULL, NULL),
(3, 1947625978, '7c222fb2927d828af22f592134e8932480637c0d', 'Munna', 'Tofayel', 'Foise Lake, Chittagang', NULL, NULL, NULL, NULL, NULL, 'ABCD', 'Male', 'Islam', 13, 3, NULL, 'School', '', 18, 18, NULL, '1', 1, '2022-12-26 18:48:15', NULL, '2023-01-15 11:13:33', NULL, NULL),
(4, 1924329315, '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 'Syed Salim Ertaza', 'Noapara Jessore', NULL, NULL, NULL, NULL, NULL, 'NSHS', 'Male', 'Islam', 16, 9, 2, 'School', '', NULL, NULL, NULL, '1', 1, '2022-12-31 10:34:30', NULL, '2023-01-26 12:56:19', NULL, NULL),
(5, 1923179437, '7c222fb2927d828af22f592134e8932480637c0d', 'murad', 'test', 'test', NULL, NULL, NULL, NULL, NULL, 'NSHS', 'Male', 'Islam', 18, 9, 1, 'School', '', 2, 2, NULL, '1', 1, '2022-12-31 18:07:36', NULL, '2022-12-31 18:21:21', NULL, NULL),
(6, 1409532730, '7c222fb2927d828af22f592134e8932480637c0d', 'hgh', 'gfgfg', 'hjh', NULL, NULL, NULL, NULL, NULL, 'ABCD', 'Male', 'Islam', 19, 1, NULL, 'Madrasha', '', NULL, NULL, NULL, '1', 1, '2023-01-12 20:51:52', NULL, '2023-01-12 20:58:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `class_id`, `class_group_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, NULL, 'বাংলা', '1', 1, '2022-12-26 18:12:46', NULL, '2023-01-02 18:33:52', NULL, NULL),
(2, 1, NULL, 'English', '1', 1, '2022-12-26 18:12:55', NULL, '2022-12-26 18:12:55', NULL, NULL),
(3, 1, NULL, 'Math', '1', 1, '2022-12-26 18:13:05', NULL, '2022-12-26 18:13:05', NULL, NULL),
(4, 2, NULL, 'বাংলা', '1', 1, '2022-12-26 18:13:18', NULL, '2023-01-02 18:34:09', NULL, NULL),
(5, 2, NULL, 'English', '1', 1, '2022-12-26 18:13:26', NULL, '2022-12-26 18:13:26', NULL, NULL),
(6, 2, NULL, 'Math', '1', 1, '2022-12-26 18:13:35', NULL, '2022-12-26 18:13:35', NULL, NULL),
(7, 3, NULL, 'বাংলা', '1', 1, '2022-12-26 18:13:47', NULL, '2023-01-02 18:34:16', NULL, NULL),
(8, 3, NULL, 'English', '1', 1, '2022-12-26 18:13:56', NULL, '2022-12-26 18:13:56', NULL, NULL),
(9, 3, NULL, 'Math', '1', 1, '2022-12-26 18:14:04', NULL, '2022-12-26 18:14:04', NULL, NULL),
(10, 4, NULL, 'বাংলা', '1', 1, '2022-12-26 18:18:19', NULL, '2023-01-02 18:34:24', NULL, NULL),
(11, 4, NULL, 'English', '1', 1, '2022-12-26 18:18:28', NULL, '2022-12-26 18:18:28', NULL, NULL),
(12, 4, NULL, 'Math', '1', 1, '2022-12-26 18:18:40', NULL, '2022-12-26 18:18:40', NULL, NULL),
(13, 5, NULL, 'বাংলা', '1', 1, '2022-12-26 18:19:02', NULL, '2023-01-02 18:34:53', NULL, NULL),
(14, 5, NULL, 'English', '1', 1, '2022-12-26 18:19:11', NULL, '2022-12-26 18:19:11', NULL, NULL),
(15, 5, NULL, 'Math', '1', 1, '2022-12-26 18:19:21', NULL, '2022-12-26 18:19:21', NULL, NULL),
(16, 6, NULL, 'বাংলা', '1', 1, '2022-12-26 18:19:35', NULL, '2023-01-02 18:34:42', NULL, NULL),
(17, 6, NULL, 'English', '1', 1, '2022-12-26 18:19:47', NULL, '2022-12-26 18:19:47', NULL, NULL),
(18, 6, NULL, 'Math', '1', 1, '2022-12-26 18:19:58', NULL, '2022-12-26 18:19:58', NULL, NULL),
(19, 7, NULL, 'বাংলা', '1', 1, '2022-12-26 18:20:55', NULL, '2023-01-02 18:35:06', NULL, NULL),
(20, 7, NULL, 'English', '1', 1, '2022-12-26 18:21:04', NULL, '2022-12-26 18:21:04', NULL, NULL),
(21, 7, NULL, 'Math', '1', 1, '2022-12-26 18:21:14', NULL, '2022-12-26 18:21:14', NULL, NULL),
(22, 8, NULL, 'বাংলা', '1', 1, '2022-12-26 18:21:31', NULL, '2023-01-02 18:35:52', NULL, NULL),
(23, 8, NULL, 'English', '1', 1, '2022-12-26 18:21:40', NULL, '2022-12-26 18:21:40', NULL, NULL),
(24, 8, NULL, 'Math', '1', 1, '2022-12-26 18:21:50', NULL, '2022-12-26 18:21:50', NULL, NULL),
(25, 9, NULL, 'বাংলা', '1', 1, '2022-12-26 18:22:04', NULL, '2023-01-02 18:35:43', NULL, NULL),
(26, 9, NULL, 'English', '1', 1, '2022-12-26 18:22:28', NULL, '2022-12-26 18:22:28', NULL, NULL),
(27, 9, NULL, 'Math', '1', 1, '2022-12-26 18:22:43', NULL, '2022-12-26 18:22:43', NULL, NULL),
(28, 10, NULL, 'বাংলা ১০', '1', 1, '2022-12-26 18:24:10', NULL, '2023-01-02 18:35:26', NULL, NULL),
(29, 10, NULL, 'English', '1', 1, '2022-12-26 18:24:21', NULL, '2022-12-26 18:24:21', NULL, NULL),
(30, 10, NULL, 'Math', '1', 1, '2022-12-26 18:24:32', NULL, '2022-12-26 18:24:32', NULL, NULL),
(31, 8, NULL, 'ICT', '1', 1, '2022-12-27 19:21:27', NULL, '2022-12-27 19:21:27', NULL, NULL),
(32, 7, NULL, 'ICT', '1', 1, '2022-12-27 19:21:35', NULL, '2022-12-27 19:21:35', NULL, NULL),
(33, 6, NULL, 'ICT', '1', 1, '2022-12-27 19:21:44', NULL, '2022-12-27 19:21:44', NULL, NULL),
(34, 6, NULL, 'ISLAMIC ST.', '1', 1, '2022-12-27 19:22:01', NULL, '2022-12-27 19:22:01', NULL, NULL),
(35, 7, NULL, 'ISLAMIC ST.', '1', 1, '2022-12-27 19:22:06', NULL, '2022-12-27 19:22:06', NULL, NULL),
(36, 9, NULL, 'ICT', '1', 1, '2022-12-27 19:22:40', NULL, '2022-12-27 19:22:40', NULL, NULL),
(37, 10, NULL, 'ICT 10', '1', 1, '2022-12-27 19:22:50', NULL, '2022-12-27 19:22:50', NULL, NULL),
(38, 9, 2, 'Physics', '1', 1, '2022-12-29 21:00:03', NULL, '2022-12-29 21:00:03', NULL, NULL),
(39, 9, 3, 'Finance', '1', 1, '2022-12-31 18:14:00', NULL, '2022-12-31 18:14:00', NULL, NULL),
(40, 9, 1, 'Home Science', '1', 1, '2022-12-31 18:14:43', NULL, '2022-12-31 18:14:43', NULL, NULL),
(41, 10, 2, 'Chemistry 10', '1', 1, '2022-12-31 20:34:43', NULL, '2022-12-31 20:34:43', NULL, NULL),
(42, 1, NULL, 'বাংলা', '1', 1, '2023-01-02 18:32:57', NULL, '2023-01-02 18:32:57', NULL, NULL),
(43, 1, NULL, 'ইংরেজী', '1', 1, '2023-01-02 18:33:57', NULL, '2023-01-02 18:33:57', NULL, NULL),
(44, 1, NULL, 'গণিত', '1', 1, '2023-01-02 18:34:28', NULL, '2023-01-02 18:34:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) DEFAULT NULL,
  `address` text,
  `pic` varchar(100) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Murad', NULL, '', NULL, 1, '1', 1, '2022-12-28 18:46:57', NULL, '2023-01-01 17:17:20', NULL, NULL),
(2, 'munnabhai@name.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Munna', 1409532730, 'clinic para, Noapara, Jashore', 'user_1672582098_5b09f40e9a13024ea9b0.png', 1, '1', 1, '2022-12-28 18:47:59', NULL, '2023-01-01 20:08:18', NULL, NULL),
(3, 'english@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'English', NULL, '', NULL, 2, '1', 1, '2023-01-01 17:13:11', NULL, '2023-01-01 17:18:43', NULL, NULL),
(4, 'abhasibul@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Hasibul Islam', 0, '', 'user_1672583334_ca4a460fa8a40f4aba85.jpeg', 1, '1', 1, '2023-01-01 20:28:31', NULL, '2023-01-01 20:28:54', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary`
--

CREATE TABLE `vocabulary` (
  `voc_id` int(11) NOT NULL,
  `english` text NOT NULL,
  `bangla` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary`
--

INSERT INTO `vocabulary` (`voc_id`, `english`, `bangla`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Go', 'যাওয়া', 1, '2022-09-07 19:03:34', NULL, '2022-09-07 19:03:34', NULL, NULL),
(2, 'OK', 'ঠিক আছে', 1, '2022-09-07 19:04:12', NULL, '2022-09-07 19:04:12', NULL, NULL),
(3, 'Yes', 'হ্যাঁ', 1, '2022-09-07 19:04:31', NULL, '2022-09-07 19:04:31', NULL, NULL),
(4, 'No', 'না', 1, '2022-09-07 19:04:52', NULL, '2022-09-07 19:04:52', NULL, NULL),
(5, 'Very ', 'খুব', 1, '2022-09-07 19:05:12', NULL, '2022-09-07 19:05:12', NULL, NULL),
(6, 'Good', 'ভাল', 1, '2022-09-07 19:06:07', NULL, '2022-09-07 19:06:07', NULL, NULL),
(7, 'Bad', 'খারাপ', 1, '2022-09-07 19:06:23', NULL, '2022-09-07 19:06:23', NULL, NULL),
(8, 'Boy', 'ছেলে', 1, '2022-09-15 19:20:35', NULL, '2022-09-15 19:20:35', NULL, NULL),
(9, 'Girl', 'মেয়ে', 1, '2022-09-15 19:21:04', NULL, '2022-09-15 19:21:04', NULL, NULL),
(10, 'Right', 'ঠিক', 1, '2022-09-22 19:46:27', NULL, '2022-09-22 19:46:27', NULL, NULL),
(11, 'Cat', 'বিল্লু', 1, '2022-12-28 20:27:44', NULL, '2022-12-28 20:30:24', NULL, NULL),
(12, 'Chair', 'কেদারা', 1, '2022-12-28 20:33:33', NULL, '2022-12-28 20:33:33', NULL, NULL),
(13, 'Hen', 'মুরগি', 1, '2022-12-31 19:07:39', NULL, '2022-12-31 19:07:39', NULL, NULL),
(14, 'Apple', 'আপেল', 1, '2022-12-31 19:07:41', NULL, '2022-12-31 19:07:41', NULL, NULL),
(15, 'clear', 'স্পষ্ট', 1, '2022-12-31 19:08:50', NULL, '2022-12-31 19:08:50', NULL, NULL),
(16, 'Cold', 'ঠান্ডা', 1, '2022-12-31 19:09:23', NULL, '2022-12-31 19:09:23', NULL, NULL),
(17, 'Apple', 'আপেল', 1, '2022-12-31 19:09:47', NULL, '2022-12-31 19:09:47', NULL, NULL),
(18, 'Orange', 'কমলা', 1, '2022-12-31 19:10:39', NULL, '2022-12-31 19:10:39', NULL, NULL),
(19, 'Banana', 'কলা', 1, '2022-12-31 19:11:43', NULL, '2022-12-31 19:11:43', NULL, NULL),
(20, 'Very', 'খুব', 1, '2022-12-31 19:12:05', NULL, '2022-12-31 19:12:05', NULL, NULL),
(21, 'alright', 'ঠিক আছে', 1, '2022-12-31 19:12:21', NULL, '2022-12-31 19:12:21', NULL, NULL),
(22, 'College', 'কলেজ', 1, '2022-12-31 19:12:34', NULL, '2022-12-31 19:12:34', NULL, NULL),
(23, 'also', 'এছাড়াও', 1, '2022-12-31 19:12:47', NULL, '2022-12-31 19:12:47', NULL, NULL),
(24, 'aa', 'aaa', 1, '2022-12-31 19:18:09', NULL, '2022-12-31 19:18:09', NULL, NULL),
(25, 'A', 'aaa', 1, '2023-01-01 19:09:10', NULL, '2023-01-01 19:17:00', NULL, NULL),
(26, 'B', 'bbbb', 1, '2023-01-01 19:09:15', NULL, '2023-01-01 19:17:09', NULL, NULL),
(27, 'C', 'cccc', 1, '2023-01-01 19:09:22', NULL, '2023-01-01 19:17:15', NULL, NULL),
(28, 'D', 'd', 1, '2023-01-01 19:09:28', NULL, '2023-01-01 19:09:28', NULL, NULL),
(29, 'E', 'e', 1, '2023-01-01 19:09:31', NULL, '2023-01-01 19:09:31', NULL, NULL),
(30, 'F', 'f', 1, '2023-01-01 19:09:37', NULL, '2023-01-01 19:09:37', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam`
--

CREATE TABLE `vocabulary_exam` (
  `voc_exam_id` int(11) NOT NULL,
  `published_date` date NOT NULL,
  `title` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Published','Unpublished') NOT NULL DEFAULT 'Unpublished',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_exam`
--

INSERT INTO `vocabulary_exam` (`voc_exam_id`, `published_date`, `title`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, '2022-12-28', '1st Test', 'Published', 1, '2022-12-28 20:27:19', NULL, '2022-12-28 20:28:00', NULL, NULL),
(2, '2022-12-31', 'Vocabulary 2nd', 'Published', 1, '2022-12-31 19:18:15', NULL, '2022-12-31 19:19:14', NULL, NULL),
(3, '2023-01-01', '01/01/23', 'Published', 1, '2023-01-01 12:08:29', NULL, '2023-01-01 12:08:38', NULL, NULL),
(4, '2023-01-02', '2/01/2023', 'Published', 1, '2023-01-01 17:18:53', NULL, '2023-01-01 19:22:59', NULL, NULL),
(5, '2023-01-01', '1/01/2023', 'Published', 1, '2023-01-01 19:24:00', NULL, '2023-01-01 19:24:18', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam_joined`
--

CREATE TABLE `vocabulary_exam_joined` (
  `voc_mcq_joined_id` int(11) NOT NULL,
  `voc_exam_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) UNSIGNED DEFAULT NULL,
  `incorrect_answers` int(11) UNSIGNED DEFAULT NULL,
  `earn_points` int(11) UNSIGNED DEFAULT NULL,
  `earn_coins` int(11) UNSIGNED DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_exam_joined`
--

INSERT INTO `vocabulary_exam_joined` (`voc_mcq_joined_id`, `voc_exam_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 16, NULL, 32, 32, 1, '2022-12-28 20:28:32', NULL, '2022-12-28 20:29:06', NULL, NULL),
(2, 1, 2, 30, NULL, 60, 60, 2, '2022-12-28 20:30:41', NULL, '2022-12-28 20:31:00', NULL, NULL),
(3, 2, 1, 45, 2, 90, 90, 1, '2022-12-31 19:20:06', NULL, '2022-12-31 19:20:59', NULL, NULL),
(5, 2, 2, 1, NULL, 2, 2, 2, '2022-12-31 21:01:24', NULL, '2022-12-31 21:01:29', NULL, NULL),
(6, 3, 1, 4, NULL, 8, 8, 1, '2023-01-01 12:08:56', NULL, '2023-01-01 12:09:13', NULL, NULL),
(7, 3, 3, 2, NULL, 4, 4, 3, '2023-01-01 18:11:46', NULL, '2023-01-01 18:11:58', NULL, NULL),
(8, 5, 1, 1, NULL, 2, 2, 1, '2023-01-01 19:24:27', NULL, '2023-01-01 19:24:30', NULL, NULL),
(9, 5, 3, 3, NULL, 6, 6, 3, '2023-01-01 20:20:34', NULL, '2023-01-01 20:21:09', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam_r_quiz`
--

CREATE TABLE `vocabulary_exam_r_quiz` (
  `exam_quiz_id` int(11) NOT NULL,
  `voc_exam_id` int(11) NOT NULL,
  `voc_quiz_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_exam_r_quiz`
--

INSERT INTO `vocabulary_exam_r_quiz` (`exam_quiz_id`, `voc_exam_id`, `voc_quiz_id`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(3, 1, 1, 1, '2022-12-28 20:28:49', NULL, '2022-12-28 20:28:49', NULL, NULL),
(5, 2, 2, 1, '2022-12-31 19:19:14', NULL, '2022-12-31 19:19:14', NULL, NULL),
(10, 3, 1, 1, '2023-01-01 12:08:39', NULL, '2023-01-01 12:08:39', NULL, NULL),
(11, 3, 2, 1, '2023-01-01 12:08:39', NULL, '2023-01-01 12:08:39', NULL, NULL),
(12, 3, 3, 1, '2023-01-01 12:08:39', NULL, '2023-01-01 12:08:39', NULL, NULL),
(13, 3, 4, 1, '2023-01-01 12:08:39', NULL, '2023-01-01 12:08:39', NULL, NULL),
(20, 4, 2, 1, '2023-01-01 19:23:34', NULL, '2023-01-01 19:23:34', NULL, NULL),
(21, 4, 4, 1, '2023-01-01 19:23:34', NULL, '2023-01-01 19:23:34', NULL, NULL),
(31, 5, 5, 1, '2023-01-01 20:19:49', NULL, '2023-01-01 20:19:49', NULL, NULL),
(32, 5, 6, 1, '2023-01-01 20:19:49', NULL, '2023-01-01 20:19:49', NULL, NULL),
(33, 5, 7, 1, '2023-01-01 20:19:49', NULL, '2023-01-01 20:19:49', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_quiz`
--

CREATE TABLE `vocabulary_quiz` (
  `voc_quiz_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_quiz`
--

INSERT INTO `vocabulary_quiz` (`voc_quiz_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Cat', 'গরৃু', 'ছাগল', 'বিড়াল', 'মুরগি', 'three', '1', 1, '2022-12-28 19:02:22', NULL, '2022-12-28 19:02:22', NULL, NULL),
(2, 'What is a ? ', 'a', 'b', 'c', 'd', 'one', '1', 1, '2022-12-31 19:16:40', NULL, '2022-12-31 19:16:40', NULL, NULL),
(3, 'Also', 'এছাড়াও', 'a', 'a', 'v', 'one', '1', 1, '2023-01-01 12:03:18', NULL, '2023-01-01 12:03:18', NULL, NULL),
(4, 'and', '1', '1', 'এবং', '1', 'three', '1', 1, '2023-01-01 12:03:40', NULL, '2023-01-01 12:03:40', NULL, NULL),
(5, 'a', 'a', 'aaa', 'aaaaa', 'aa', 'one', '1', 1, '2023-01-01 19:19:15', NULL, '2023-01-01 19:19:15', NULL, NULL),
(6, 'b', 'b', 'bb', 'bbb', 'bbbb', 'one', '1', 1, '2023-01-01 19:19:30', NULL, '2023-01-01 19:19:30', NULL, NULL),
(7, 'c', 'cc', 'c', 'ccc', 'cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccdfdfffffffffdssssssssssssssssssssssddddddddddddddd dddddddddssss sssssssssssf a  dfdsafdas f dsfsdfds dsfdsf sdfdv ', 'two', '1', 1, '2023-01-01 19:20:02', NULL, '2023-01-01 19:20:02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_read`
--

CREATE TABLE `vocabulary_read` (
  `voc_read_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `count` int(11) UNSIGNED NOT NULL,
  `last_seen_date` date NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_read`
--

INSERT INTO `vocabulary_read` (`voc_read_id`, `std_id`, `count`, `last_seen_date`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 2, 25, '2023-01-09', 2, '2022-12-26 19:08:13', 2, NULL, NULL, NULL),
(2, 1, 25, '2023-01-09', 1, '2022-12-28 20:02:59', 1, NULL, NULL, NULL),
(3, 3, 20, '2023-01-01', 3, '2022-12-28 20:31:18', 3, NULL, NULL, NULL),
(4, 4, 20, '2023-01-03', 4, '2022-12-31 19:17:08', 4, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `badge`
--
ALTER TABLE `badge`
  ADD PRIMARY KEY (`badge_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `chapter`
--
ALTER TABLE `chapter`
  ADD PRIMARY KEY (`chapter_id`),
  ADD KEY `parent_class_id` (`subject_id`);

--
-- Indexes for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  ADD PRIMARY KEY (`chapter_joined_id`),
  ADD UNIQUE KEY `Joined_exam_by_student` (`chapter_id`,`std_id`),
  ADD KEY `std_id` (`std_id`);

--
-- Indexes for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  ADD PRIMARY KEY (`quiz_id`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `chapter_video`
--
ALTER TABLE `chapter_video`
  ADD PRIMARY KEY (`video_id`),
  ADD UNIQUE KEY `Unique_videos` (`chapter_id`,`status`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `class_group`
--
ALTER TABLE `class_group`
  ADD PRIMARY KEY (`class_group_id`);

--
-- Indexes for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  ADD PRIMARY KEY (`class_group_jnt_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `class_group_id` (`class_group_id`);

--
-- Indexes for table `class_subscribe`
--
ALTER TABLE `class_subscribe`
  ADD PRIMARY KEY (`class_subscribe_id`),
  ADD KEY `class_id` (`std_id`),
  ADD KEY `class_subscription_package_id` (`class_subscription_package_id`);

--
-- Indexes for table `class_subscribe_package`
--
ALTER TABLE `class_subscribe_package`
  ADD PRIMARY KEY (`class_subscription_package_id`),
  ADD KEY `class_group_id` (`class_group_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `class_group_id` (`class_group_id`);

--
-- Indexes for table `course_category`
--
ALTER TABLE `course_category`
  ADD PRIMARY KEY (`course_cat_id`),
  ADD KEY `course_id` (`course_id`) USING BTREE;

--
-- Indexes for table `course_exam_joined`
--
ALTER TABLE `course_exam_joined`
  ADD PRIMARY KEY (`course_exam_joined_id`),
  ADD UNIQUE KEY `Joined_exam_by_student` (`course_video_id`,`std_id`),
  ADD KEY `std_id` (`std_id`);

--
-- Indexes for table `course_quiz`
--
ALTER TABLE `course_quiz`
  ADD PRIMARY KEY (`course_quiz_id`),
  ADD KEY `chapter_id` (`course_video_id`);

--
-- Indexes for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  ADD PRIMARY KEY (`course_subscribe_id`),
  ADD UNIQUE KEY `Unique_course_subscription` (`status`,`std_id`,`course_id`) USING BTREE,
  ADD KEY `class_id` (`std_id`),
  ADD KEY `class_group_id` (`course_id`);

--
-- Indexes for table `course_video`
--
ALTER TABLE `course_video`
  ADD PRIMARY KEY (`course_video_id`),
  ADD KEY `chapter_id` (`course_id`),
  ADD KEY `course_cat_id` (`course_cat_id`);

--
-- Indexes for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  ADD PRIMARY KEY (`history_user_coin_id`),
  ADD KEY `sch_id` (`std_id`),
  ADD KEY `inv_id` (`order_id`),
  ADD KEY `chapter_joined_id` (`chapter_joined_id`),
  ADD KEY `mcq_joined_id` (`mcq_joined_id`),
  ADD KEY `voc_mcq_joined_id` (`voc_mcq_joined_id`),
  ADD KEY `qe_joined_id` (`qe_joined_id`),
  ADD KEY `course_exam_joined_id` (`course_exam_joined_id`);

--
-- Indexes for table `history_user_point`
--
ALTER TABLE `history_user_point`
  ADD PRIMARY KEY (`history_user_point_id`),
  ADD KEY `sch_id` (`std_id`),
  ADD KEY `inv_id` (`order_id`),
  ADD KEY `chapter_joined_id` (`chapter_joined_id`),
  ADD KEY `mcq_joined_id` (`mcq_joined_id`),
  ADD KEY `qe_joined_id` (`qe_joined_id`),
  ADD KEY `voc_mcq_joined_id` (`voc_mcq_joined_id`);

--
-- Indexes for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  ADD PRIMARY KEY (`mcq_joined_id`),
  ADD KEY `skill_video_id` (`skill_video_id`),
  ADD KEY `std_id` (`std_id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `notice_send`
--
ALTER TABLE `notice_send`
  ADD PRIMARY KEY (`send_notice_id`),
  ADD KEY `notice_id` (`notice_id`),
  ADD KEY `receiver_std_id` (`receiver_std_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `pymnt_type_id` (`pymnt_method_id`),
  ADD KEY `customer_id` (`std_id`) USING BTREE;

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `invoice_id` (`order_id`),
  ADD KEY `inv_exist_item_id` (`prod_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `course_subscribe_id` (`course_subscribe_id`),
  ADD KEY `std_id` (`std_id`),
  ADD KEY `payment_ibfk_3` (`class_subscribe_id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`pymnt_method_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `prod_cat_id` (`prod_cat_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`prod_cat_id`);

--
-- Indexes for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  ADD PRIMARY KEY (`quiz_exam_info_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  ADD PRIMARY KEY (`qe_joined_id`),
  ADD UNIQUE KEY `quiz_exam_unique` (`quiz_exam_info_id`,`std_id`),
  ADD KEY `std_id` (`std_id`);

--
-- Indexes for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  ADD PRIMARY KEY (`quiz_question_id`),
  ADD KEY `quiz_exam_info_id` (`quiz_exam_info_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settings_id`);

--
-- Indexes for table `skill_questions`
--
ALTER TABLE `skill_questions`
  ADD PRIMARY KEY (`skill_question_id`),
  ADD KEY `skill_video_id` (`skill_video_id`);

--
-- Indexes for table `skill_subject`
--
ALTER TABLE `skill_subject`
  ADD PRIMARY KEY (`skill_subject_id`);

--
-- Indexes for table `skill_video`
--
ALTER TABLE `skill_video`
  ADD PRIMARY KEY (`skill_video_id`),
  ADD KEY `chapter_id` (`skill_subject_id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`store_id`),
  ADD KEY `prod_id` (`prod_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`std_id`),
  ADD UNIQUE KEY `phone` (`phone`) USING BTREE,
  ADD KEY `class_id` (`class_id`),
  ADD KEY `badge_id` (`badge_id`),
  ADD KEY `class_group_id` (`class_group_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `parent_class_id` (`class_id`),
  ADD KEY `class_group_id` (`class_group_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vocabulary`
--
ALTER TABLE `vocabulary`
  ADD PRIMARY KEY (`voc_id`);

--
-- Indexes for table `vocabulary_exam`
--
ALTER TABLE `vocabulary_exam`
  ADD PRIMARY KEY (`voc_exam_id`);

--
-- Indexes for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  ADD PRIMARY KEY (`voc_mcq_joined_id`),
  ADD UNIQUE KEY `vocabulary_exam_join_unique` (`voc_exam_id`,`std_id`),
  ADD KEY `std_id` (`std_id`);

--
-- Indexes for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  ADD PRIMARY KEY (`exam_quiz_id`),
  ADD KEY `voc_exam_id` (`voc_exam_id`),
  ADD KEY `voc_quiz_id` (`voc_quiz_id`);

--
-- Indexes for table `vocabulary_quiz`
--
ALTER TABLE `vocabulary_quiz`
  ADD PRIMARY KEY (`voc_quiz_id`);

--
-- Indexes for table `vocabulary_read`
--
ALTER TABLE `vocabulary_read`
  ADD PRIMARY KEY (`voc_read_id`),
  ADD KEY `std_id` (`std_id`),
  ADD KEY `updatedBy` (`updatedBy`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `createdBy` (`createdBy`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `badge`
--
ALTER TABLE `badge`
  MODIFY `badge_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chapter`
--
ALTER TABLE `chapter`
  MODIFY `chapter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  MODIFY `chapter_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `chapter_video`
--
ALTER TABLE `chapter_video`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `class_group`
--
ALTER TABLE `class_group`
  MODIFY `class_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  MODIFY `class_group_jnt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `class_subscribe`
--
ALTER TABLE `class_subscribe`
  MODIFY `class_subscribe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `class_subscribe_package`
--
ALTER TABLE `class_subscribe_package`
  MODIFY `class_subscription_package_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `course_category`
--
ALTER TABLE `course_category`
  MODIFY `course_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `course_exam_joined`
--
ALTER TABLE `course_exam_joined`
  MODIFY `course_exam_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course_quiz`
--
ALTER TABLE `course_quiz`
  MODIFY `course_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  MODIFY `course_subscribe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `course_video`
--
ALTER TABLE `course_video`
  MODIFY `course_video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  MODIFY `history_user_coin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `history_user_point`
--
ALTER TABLE `history_user_point`
  MODIFY `history_user_point_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  MODIFY `mcq_joined_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `notice_send`
--
ALTER TABLE `notice_send`
  MODIFY `send_notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `pymnt_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `prod_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  MODIFY `quiz_exam_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  MODIFY `qe_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  MODIFY `quiz_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settings_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `skill_questions`
--
ALTER TABLE `skill_questions`
  MODIFY `skill_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skill_subject`
--
ALTER TABLE `skill_subject`
  MODIFY `skill_subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skill_video`
--
ALTER TABLE `skill_video`
  MODIFY `skill_video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `std_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vocabulary`
--
ALTER TABLE `vocabulary`
  MODIFY `voc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `vocabulary_exam`
--
ALTER TABLE `vocabulary_exam`
  MODIFY `voc_exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  MODIFY `voc_mcq_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  MODIFY `exam_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `vocabulary_quiz`
--
ALTER TABLE `vocabulary_quiz`
  MODIFY `voc_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vocabulary_read`
--
ALTER TABLE `vocabulary_read`
  MODIFY `voc_read_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chapter`
--
ALTER TABLE `chapter`
  ADD CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON UPDATE CASCADE;

--
-- Constraints for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  ADD CONSTRAINT `chapter_exam_joined_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `chapter_exam_joined_ibfk_2` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`) ON UPDATE CASCADE;

--
-- Constraints for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  ADD CONSTRAINT `chapter_quiz_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`) ON UPDATE CASCADE;

--
-- Constraints for table `chapter_video`
--
ALTER TABLE `chapter_video`
  ADD CONSTRAINT `chapter_video_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  ADD CONSTRAINT `class_group_joined_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `class_group_joined_ibfk_2` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class_subscribe`
--
ALTER TABLE `class_subscribe`
  ADD CONSTRAINT `class_subscribe_ibfk_3` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_subscribe_ibfk_4` FOREIGN KEY (`class_subscription_package_id`) REFERENCES `class_subscribe_package` (`class_subscription_package_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class_subscribe_package`
--
ALTER TABLE `class_subscribe_package`
  ADD CONSTRAINT `class_subscribe_package_ibfk_2` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_subscribe_package_ibfk_3` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `course_ibfk_2` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course_category`
--
ALTER TABLE `course_category`
  ADD CONSTRAINT `course_category_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course_exam_joined`
--
ALTER TABLE `course_exam_joined`
  ADD CONSTRAINT `course_exam_joined_ibfk_1` FOREIGN KEY (`course_video_id`) REFERENCES `course_video` (`course_video_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course_quiz`
--
ALTER TABLE `course_quiz`
  ADD CONSTRAINT `course_quiz_ibfk_1` FOREIGN KEY (`course_video_id`) REFERENCES `course_video` (`course_video_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  ADD CONSTRAINT `course_subscribe_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `course_subscribe_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  ADD CONSTRAINT `history_user_coin_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_3` FOREIGN KEY (`chapter_joined_id`) REFERENCES `chapter_exam_joined` (`chapter_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_4` FOREIGN KEY (`mcq_joined_id`) REFERENCES `mcq_exam_joined` (`mcq_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_5` FOREIGN KEY (`voc_mcq_joined_id`) REFERENCES `vocabulary_exam_joined` (`voc_mcq_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_6` FOREIGN KEY (`qe_joined_id`) REFERENCES `quiz_exam_joined` (`qe_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_7` FOREIGN KEY (`course_exam_joined_id`) REFERENCES `course_exam_joined` (`course_exam_joined_id`) ON UPDATE CASCADE;

--
-- Constraints for table `history_user_point`
--
ALTER TABLE `history_user_point`
  ADD CONSTRAINT `history_user_point_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_point_ibfk_2` FOREIGN KEY (`chapter_joined_id`) REFERENCES `chapter_exam_joined` (`chapter_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_point_ibfk_3` FOREIGN KEY (`mcq_joined_id`) REFERENCES `mcq_exam_joined` (`mcq_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_point_ibfk_4` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_point_ibfk_5` FOREIGN KEY (`qe_joined_id`) REFERENCES `quiz_exam_joined` (`qe_joined_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_point_ibfk_6` FOREIGN KEY (`voc_mcq_joined_id`) REFERENCES `vocabulary_exam_joined` (`voc_mcq_joined_id`) ON UPDATE CASCADE;

--
-- Constraints for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  ADD CONSTRAINT `mcq_exam_joined_ibfk_1` FOREIGN KEY (`skill_video_id`) REFERENCES `skill_video` (`skill_video_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `mcq_exam_joined_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `notice_send`
--
ALTER TABLE `notice_send`
  ADD CONSTRAINT `notice_send_ibfk_1` FOREIGN KEY (`notice_id`) REFERENCES `notice` (`notice_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `notice_send_ibfk_2` FOREIGN KEY (`receiver_std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`pymnt_method_id`) REFERENCES `payment_method` (`pymnt_method_id`) ON UPDATE CASCADE;

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `order_item_ibfk_3` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`) ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`course_subscribe_id`) REFERENCES `course_subscribe` (`course_subscribe_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`prod_cat_id`) REFERENCES `product_category` (`prod_cat_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_3` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`brand_id`) ON UPDATE CASCADE;

--
-- Constraints for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  ADD CONSTRAINT `quiz_exam_info_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `quiz_exam_info_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE;

--
-- Constraints for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  ADD CONSTRAINT `quiz_exam_joined_ibfk_1` FOREIGN KEY (`quiz_exam_info_id`) REFERENCES `quiz_exam_info` (`quiz_exam_info_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `quiz_exam_joined_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  ADD CONSTRAINT `quiz_exam_questions_ibfk_1` FOREIGN KEY (`quiz_exam_info_id`) REFERENCES `quiz_exam_info` (`quiz_exam_info_id`) ON UPDATE CASCADE;

--
-- Constraints for table `skill_questions`
--
ALTER TABLE `skill_questions`
  ADD CONSTRAINT `skill_questions_ibfk_1` FOREIGN KEY (`skill_video_id`) REFERENCES `skill_video` (`skill_video_id`) ON UPDATE CASCADE;

--
-- Constraints for table `skill_video`
--
ALTER TABLE `skill_video`
  ADD CONSTRAINT `skill_video_ibfk_1` FOREIGN KEY (`skill_subject_id`) REFERENCES `skill_subject` (`skill_subject_id`) ON UPDATE CASCADE;

--
-- Constraints for table `store`
--
ALTER TABLE `store`
  ADD CONSTRAINT `store_ibfk_1` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`) ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`badge_id`) REFERENCES `badge` (`badge_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_3` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_ibfk_2` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE;

--
-- Constraints for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  ADD CONSTRAINT `vocabulary_exam_joined_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `vocabulary_exam_joined_ibfk_2` FOREIGN KEY (`voc_exam_id`) REFERENCES `vocabulary_exam` (`voc_exam_id`) ON UPDATE CASCADE;

--
-- Constraints for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  ADD CONSTRAINT `vocabulary_exam_r_quiz_ibfk_1` FOREIGN KEY (`voc_exam_id`) REFERENCES `vocabulary_exam` (`voc_exam_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `vocabulary_exam_r_quiz_ibfk_2` FOREIGN KEY (`voc_quiz_id`) REFERENCES `vocabulary_quiz` (`voc_quiz_id`) ON UPDATE CASCADE;

--
-- Constraints for table `vocabulary_read`
--
ALTER TABLE `vocabulary_read`
  ADD CONSTRAINT `vocabulary_read_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
