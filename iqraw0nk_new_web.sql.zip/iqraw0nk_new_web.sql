-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 11, 2022 at 06:47 AM
-- Server version: 5.7.23-23
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iqraw0nk_new_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 1924329315, 'Noapara, Abhaynagar, Jessore', 'profile.jpg', NULL, NULL, 1, '1', 1, '2018-11-21 18:05:40', 1, '2019-11-10 22:20:42', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `badge`
--

CREATE TABLE `badge` (
  `badge_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `ranking` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `logo` varchar(256) DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) DEFAULT NULL,
  `updateDtm` timestamp NULL DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `chapter`
--

CREATE TABLE `chapter` (
  `chapter_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chapter_exam_joined`
--

CREATE TABLE `chapter_exam_joined` (
  `chapter_joined_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chapter_quiz`
--

CREATE TABLE `chapter_quiz` (
  `quiz_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chapter_video`
--

CREATE TABLE `chapter_video` (
  `video_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class_group`
--

CREATE TABLE `class_group` (
  `class_group_id` int(11) NOT NULL,
  `group_name` varchar(155) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `class_group_joined`
--

CREATE TABLE `class_group_joined` (
  `class_group_jnt_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `class_group_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(155) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `price` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course_category`
--

CREATE TABLE `course_category` (
  `course_cat_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `category_name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course_subscribe`
--

CREATE TABLE `course_subscribe` (
  `course_subscribe_id` int(11) NOT NULL,
  `std_id` int(11) DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `subs_time` int(11) DEFAULT NULL COMMENT 'Value is calculated with month.',
  `status` enum('1','0') NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course_video`
--

CREATE TABLE `course_video` (
  `course_video_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_cat_id` int(11) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `thumb` text,
  `author` varchar(155) NOT NULL,
  `total_views` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `history_user_coin`
--

CREATE TABLE `history_user_coin` (
  `history_user_coin_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `chapter_joined_id` int(11) DEFAULT NULL,
  `mcq_joined_id` int(11) DEFAULT NULL,
  `qe_joined_id` int(11) DEFAULT NULL,
  `voc_mcq_joined_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double UNSIGNED NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `history_user_point`
--

CREATE TABLE `history_user_point` (
  `history_user_point_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `chapter_joined_id` int(11) DEFAULT NULL,
  `mcq_joined_id` int(11) DEFAULT NULL,
  `qe_joined_id` int(11) DEFAULT NULL,
  `voc_mcq_joined_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double UNSIGNED NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mcq_exam_joined`
--

CREATE TABLE `mcq_exam_joined` (
  `mcq_joined_id` int(11) NOT NULL,
  `skill_video_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `std_id` int(11) DEFAULT NULL,
  `pymnt_method_id` int(11) DEFAULT NULL,
  `amount` double UNSIGNED NOT NULL,
  `entire_sale_discount` int(11) UNSIGNED DEFAULT NULL,
  `vat` int(11) UNSIGNED DEFAULT NULL,
  `delivery_charge` int(11) UNSIGNED DEFAULT NULL,
  `final_amount` double UNSIGNED NOT NULL,
  `global_address_id` int(11) NOT NULL,
  `status` enum('1','0','2','3') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '2=pandding,0=unpaid,1=paid,3=cancel',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `year` longtext COLLATE utf8_unicode_ci,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `price` double UNSIGNED NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `total_price` double UNSIGNED NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `final_price` double UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) UNSIGNED DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `pymnt_method_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `icon` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`pymnt_method_id`, `type_name`, `icon`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Coin', '', 0, '2022-08-08 18:43:27', NULL, '2022-08-08 18:43:27', NULL, NULL),
(2, 'Bkash', '', 1, '2022-08-13 12:23:44', NULL, '2022-08-13 12:23:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `name` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `price` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `picture` varchar(155) DEFAULT NULL,
  `prod_cat_id` int(11) DEFAULT NULL,
  `product_type` enum('1','2') NOT NULL DEFAULT '1',
  `gender_type` enum('Man','Women','Both') NOT NULL DEFAULT 'Both',
  `description` text,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `prod_cat_id` int(11) NOT NULL,
  `parent_pro_cat_id` int(11) NOT NULL,
  `product_category` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_info`
--

CREATE TABLE `quiz_exam_info` (
  `quiz_exam_info_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `quiz_name` text NOT NULL,
  `total_questions` int(11) DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_joined`
--

CREATE TABLE `quiz_exam_joined` (
  `qe_joined_id` int(11) NOT NULL,
  `quiz_exam_info_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_questions`
--

CREATE TABLE `quiz_exam_questions` (
  `quiz_question_id` int(11) NOT NULL,
  `quiz_exam_info_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `permission` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedby` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role`, `permission`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Student\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User_roll\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Quiz_question\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary_exam\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Store\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"ProductCategory\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Order\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class_group\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Subscribe\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', 1, '2022-06-26 13:05:05', NULL, '2022-08-24 19:39:42', NULL, NULL),
(2, 'Maneger', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Student\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Class\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Chapter\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Chapter_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Chapter_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"0\",\"delete\":\"0\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"User_roll\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"0\",\"delete\":\"0\"}}', 1, '2022-06-26 18:16:14', NULL, '2022-06-26 18:16:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` text,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`settings_id`, `label`, `value`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'points_chapter_mcq', '1', 1, '2022-06-13 11:51:50', NULL, '2022-06-19 18:45:14', NULL, NULL),
(2, 'points_semister_mcq', '1', 1, '2022-06-13 11:52:49', NULL, '2022-06-13 11:52:49', NULL, NULL),
(3, 'points_vocabulary_mcq', '2', 1, '2022-06-13 11:53:50', NULL, '2022-07-28 18:23:40', NULL, NULL),
(7, 'points_video_mcq', '1', 1, '2022-07-19 09:59:40', NULL, '2022-07-19 09:59:40', NULL, NULL),
(8, 'vocabulary_quiz_view_frontEnd', '5', 1, '2022-07-26 12:57:41', NULL, '2022-11-13 11:38:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_questions`
--

CREATE TABLE `skill_questions` (
  `skill_question_id` int(11) NOT NULL,
  `skill_video_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skill_subject`
--

CREATE TABLE `skill_subject` (
  `skill_subject_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skill_video`
--

CREATE TABLE `skill_video` (
  `skill_video_id` int(11) NOT NULL,
  `skill_subject_id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `thumb` text,
  `author` varchar(155) NOT NULL,
  `total_views` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `store_id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `quantity` int(11) UNSIGNED DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `purchase_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Last purchase price will be added here.',
  `is_default` enum('0','1') NOT NULL DEFAULT '0',
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) DEFAULT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`store_id`, `name`, `prod_id`, `quantity`, `unit`, `purchase_date`, `is_default`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 'Default', NULL, NULL, NULL, '2022-08-03 12:19:10', '0', '2022-08-03 06:19:10', NULL, '2022-08-03 06:19:10', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `std_id` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `father_name` text,
  `address` text,
  `school_name` varchar(155) DEFAULT NULL,
  `gender` enum('Male','Female','Unisex') DEFAULT NULL,
  `religion` enum('Islam','Hindu','Christian','Buddhism') DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `class_id` int(5) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `institute` enum('School','Madrasha') NOT NULL DEFAULT 'School',
  `pic` varchar(100) NOT NULL,
  `point` int(11) DEFAULT NULL,
  `coin` int(11) DEFAULT NULL,
  `badge_id` int(11) DEFAULT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) DEFAULT NULL,
  `address` text,
  `pic` varchar(100) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'murad@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Murad', NULL, NULL, NULL, 2, '1', 1, '2022-06-26 18:16:45', NULL, '2022-06-26 18:16:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary`
--

CREATE TABLE `vocabulary` (
  `voc_id` int(11) NOT NULL,
  `english` text NOT NULL,
  `bangla` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary`
--

INSERT INTO `vocabulary` (`voc_id`, `english`, `bangla`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'A little', 'সামান্য', 1, '2022-07-25 19:58:03', NULL, '2022-07-25 20:00:58', NULL, NULL),
(2, 'Register', 'নিবন্ধন', 1, '2022-07-25 20:21:01', NULL, '2022-07-25 20:21:01', NULL, NULL),
(3, 'Report', 'প্রতিবেদন', 1, '2022-07-25 20:21:27', NULL, '2022-07-25 20:21:27', NULL, NULL),
(4, 'Detail', 'বিস্তারিত', 1, '2022-07-25 20:21:51', NULL, '2022-07-25 20:21:51', NULL, NULL),
(6, 'aa', 'সামান্য', 1, '2022-07-25 19:58:03', NULL, '2022-11-13 12:37:10', NULL, NULL),
(7, 'bbb', 'নিবন্ধন', 1, '2022-07-25 20:21:01', NULL, '2022-11-13 12:37:06', NULL, NULL),
(8, 'sss', 'প্রতিবেদন', 1, '2022-07-25 20:21:27', NULL, '2022-11-13 12:36:59', NULL, NULL),
(9, 'nn', 'বিস্তারিত', 1, '2022-07-25 20:21:51', NULL, '2022-11-13 12:37:02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam`
--

CREATE TABLE `vocabulary_exam` (
  `voc_exam_id` int(11) NOT NULL,
  `published_date` date NOT NULL,
  `title` varchar(155) NOT NULL,
  `status` enum('Published','Unpublished') NOT NULL DEFAULT 'Unpublished',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam_joined`
--

CREATE TABLE `vocabulary_exam_joined` (
  `voc_mcq_joined_id` int(11) NOT NULL,
  `voc_exam_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam_r_quiz`
--

CREATE TABLE `vocabulary_exam_r_quiz` (
  `exam_quiz_id` int(11) NOT NULL,
  `voc_exam_id` int(11) NOT NULL,
  `voc_quiz_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_quiz`
--

CREATE TABLE `vocabulary_quiz` (
  `voc_quiz_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_read`
--

CREATE TABLE `vocabulary_read` (
  `voc_read_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `last_seen_date` date NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `badge`
--
ALTER TABLE `badge`
  ADD PRIMARY KEY (`badge_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `chapter`
--
ALTER TABLE `chapter`
  ADD PRIMARY KEY (`chapter_id`),
  ADD KEY `parent_class_id` (`subject_id`);

--
-- Indexes for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  ADD PRIMARY KEY (`chapter_joined_id`);

--
-- Indexes for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  ADD PRIMARY KEY (`quiz_id`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `chapter_video`
--
ALTER TABLE `chapter_video`
  ADD PRIMARY KEY (`video_id`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `class_group`
--
ALTER TABLE `class_group`
  ADD PRIMARY KEY (`class_group_id`);

--
-- Indexes for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  ADD PRIMARY KEY (`class_group_jnt_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `class_group_id` (`class_group_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `course_category`
--
ALTER TABLE `course_category`
  ADD PRIMARY KEY (`course_cat_id`);

--
-- Indexes for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  ADD PRIMARY KEY (`course_subscribe_id`),
  ADD KEY `class_id` (`std_id`),
  ADD KEY `class_group_id` (`course_id`);

--
-- Indexes for table `course_video`
--
ALTER TABLE `course_video`
  ADD PRIMARY KEY (`course_video_id`),
  ADD KEY `chapter_id` (`course_id`);

--
-- Indexes for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  ADD PRIMARY KEY (`history_user_coin_id`),
  ADD KEY `sch_id` (`std_id`),
  ADD KEY `inv_id` (`order_id`);

--
-- Indexes for table `history_user_point`
--
ALTER TABLE `history_user_point`
  ADD PRIMARY KEY (`history_user_point_id`),
  ADD KEY `sch_id` (`std_id`),
  ADD KEY `inv_id` (`order_id`);

--
-- Indexes for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  ADD PRIMARY KEY (`mcq_joined_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `pymnt_type_id` (`pymnt_method_id`),
  ADD KEY `customer_id` (`std_id`) USING BTREE;

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `invoice_id` (`order_id`),
  ADD KEY `inv_exist_item_id` (`prod_id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`pymnt_method_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `prod_cat_id` (`prod_cat_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`prod_cat_id`);

--
-- Indexes for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  ADD PRIMARY KEY (`quiz_exam_info_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  ADD PRIMARY KEY (`qe_joined_id`);

--
-- Indexes for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  ADD PRIMARY KEY (`quiz_question_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settings_id`);

--
-- Indexes for table `skill_questions`
--
ALTER TABLE `skill_questions`
  ADD PRIMARY KEY (`skill_question_id`);

--
-- Indexes for table `skill_subject`
--
ALTER TABLE `skill_subject`
  ADD PRIMARY KEY (`skill_subject_id`);

--
-- Indexes for table `skill_video`
--
ALTER TABLE `skill_video`
  ADD PRIMARY KEY (`skill_video_id`),
  ADD KEY `chapter_id` (`skill_subject_id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`std_id`),
  ADD UNIQUE KEY `phone` (`phone`) USING BTREE,
  ADD KEY `class_id` (`class_id`),
  ADD KEY `badge_id` (`badge_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `parent_class_id` (`class_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vocabulary`
--
ALTER TABLE `vocabulary`
  ADD PRIMARY KEY (`voc_id`);

--
-- Indexes for table `vocabulary_exam`
--
ALTER TABLE `vocabulary_exam`
  ADD PRIMARY KEY (`voc_exam_id`);

--
-- Indexes for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  ADD PRIMARY KEY (`voc_mcq_joined_id`);

--
-- Indexes for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  ADD PRIMARY KEY (`exam_quiz_id`);

--
-- Indexes for table `vocabulary_quiz`
--
ALTER TABLE `vocabulary_quiz`
  ADD PRIMARY KEY (`voc_quiz_id`);

--
-- Indexes for table `vocabulary_read`
--
ALTER TABLE `vocabulary_read`
  ADD PRIMARY KEY (`voc_read_id`),
  ADD KEY `std_id` (`std_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `badge`
--
ALTER TABLE `badge`
  MODIFY `badge_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chapter`
--
ALTER TABLE `chapter`
  MODIFY `chapter_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  MODIFY `chapter_joined_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chapter_video`
--
ALTER TABLE `chapter_video`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class_group`
--
ALTER TABLE `class_group`
  MODIFY `class_group_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  MODIFY `class_group_jnt_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_category`
--
ALTER TABLE `course_category`
  MODIFY `course_cat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  MODIFY `course_subscribe_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_video`
--
ALTER TABLE `course_video`
  MODIFY `course_video_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  MODIFY `history_user_coin_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history_user_point`
--
ALTER TABLE `history_user_point`
  MODIFY `history_user_point_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  MODIFY `mcq_joined_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `pymnt_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `prod_cat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  MODIFY `quiz_exam_info_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  MODIFY `qe_joined_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  MODIFY `quiz_question_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settings_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `skill_questions`
--
ALTER TABLE `skill_questions`
  MODIFY `skill_question_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skill_subject`
--
ALTER TABLE `skill_subject`
  MODIFY `skill_subject_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skill_video`
--
ALTER TABLE `skill_video`
  MODIFY `skill_video_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `std_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vocabulary`
--
ALTER TABLE `vocabulary`
  MODIFY `voc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `vocabulary_exam`
--
ALTER TABLE `vocabulary_exam`
  MODIFY `voc_exam_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  MODIFY `voc_mcq_joined_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  MODIFY `exam_quiz_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vocabulary_quiz`
--
ALTER TABLE `vocabulary_quiz`
  MODIFY `voc_quiz_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vocabulary_read`
--
ALTER TABLE `vocabulary_read`
  MODIFY `voc_read_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chapter`
--
ALTER TABLE `chapter`
  ADD CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON UPDATE CASCADE;

--
-- Constraints for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  ADD CONSTRAINT `chapter_quiz_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  ADD CONSTRAINT `class_group_joined_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_group_joined_ibfk_2` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  ADD CONSTRAINT `course_subscribe_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `course_subscribe_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  ADD CONSTRAINT `history_user_coin_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `order_item_ibfk_3` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`) ON UPDATE CASCADE;

--
-- Constraints for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  ADD CONSTRAINT `quiz_exam_info_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`badge_id`) REFERENCES `badge` (`badge_id`) ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE;

--
-- Constraints for table `vocabulary_read`
--
ALTER TABLE `vocabulary_read`
  ADD CONSTRAINT `vocabulary_read_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
