-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2022 at 11:33 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iqraw`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 1924329315, 'Noapara, Abhaynagar, Jessore', 'profile.jpg', NULL, NULL, 1, '1', 1, '2018-11-21 18:05:40', 1, '2019-11-10 22:20:42', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `badge`
--

CREATE TABLE `badge` (
  `badge_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `ranking` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `logo` varchar(256) DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updateDtm` timestamp NULL DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `name`, `logo`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 'New Brand', NULL, '2022-08-03 11:39:56', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter`
--

CREATE TABLE `chapter` (
  `chapter_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter`
--

INSERT INTO `chapter` (`chapter_id`, `subject_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'first chapter', '1', 1, '2022-06-15 13:01:35', NULL, '2022-06-15 13:04:44', NULL, NULL),
(2, 1, 'Second Chapter', '1', 1, '2022-06-15 13:03:49', NULL, '2022-06-15 13:03:49', NULL, NULL),
(4, 3, 'First chapter', '1', 1, '2022-08-14 12:38:28', NULL, '2022-08-14 12:38:28', NULL, NULL),
(5, 6, 'gsdg', '1', 1, '2022-08-14 19:33:06', NULL, '2022-08-14 19:33:06', NULL, NULL),
(6, 2, 'first', '1', 1, '2022-08-15 12:17:15', NULL, '2022-08-15 12:17:15', NULL, NULL),
(7, 1, 'one', '1', 1, '2022-09-24 11:23:01', NULL, '2022-09-24 11:23:01', NULL, NULL),
(8, 10, 'Chapter One', '1', 1, '2022-09-24 11:26:43', NULL, '2022-09-24 11:26:43', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter_exam_joined`
--

CREATE TABLE `chapter_exam_joined` (
  `chapter_joined_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter_exam_joined`
--

INSERT INTO `chapter_exam_joined` (`chapter_joined_id`, `chapter_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 3, 1, 3, 3, 1, '2022-07-20 10:35:56', NULL, '2022-07-20 10:53:02', NULL, NULL),
(2, 1, 6, 2, 2, 2, 2, 6, '2022-08-02 19:20:56', NULL, '2022-08-02 19:21:17', NULL, NULL),
(3, 4, 1, NULL, 1, NULL, NULL, 1, '2022-08-14 12:41:54', NULL, '2022-08-14 12:41:59', NULL, NULL),
(4, 8, 13, 1, NULL, 1, 1, 13, '2022-09-24 11:30:56', NULL, '2022-09-24 11:31:05', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter_quiz`
--

CREATE TABLE `chapter_quiz` (
  `quiz_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter_quiz`
--

INSERT INTO `chapter_quiz` (`quiz_id`, `chapter_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-06-16 10:10:22', NULL, '2022-06-16 10:10:22', NULL, NULL),
(3, 1, 'গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-06-16 10:10:22', NULL, '2022-06-18 12:25:09', NULL, NULL),
(4, 1, 'গুনিতকের ', '40', '41', '42', '43', 'three', '1', 1, '2022-06-16 10:10:22', NULL, '2022-06-18 12:25:09', NULL, NULL),
(5, 1, 'কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-06-16 10:10:22', NULL, '2022-06-18 12:25:09', NULL, NULL),
(6, 4, 'sdfasd', 'sdsad', 'sadasd', 'asdsad', 'asdsad', 'two', '1', 1, '2022-08-14 12:38:51', NULL, '2022-08-14 12:38:51', NULL, NULL),
(7, 8, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '41', '42', '43', '44', 'two', '1', 1, '2022-09-24 11:28:26', NULL, '2022-09-24 11:28:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chapter_video`
--

CREATE TABLE `chapter_video` (
  `video_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter_video`
--

INSERT INTO `chapter_video` (`video_id`, `chapter_id`, `name`, `URL`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'not heard to take chicken', '<iframe width=\"1349\" height=\"480\" src=\"https://www.youtube.com/embed/G5TwLNB0fIY\" title=\"GIANT CRAB - catch and cook - BOW n ARROW. Cooking on a camp fire. EP 83\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '1', 1, '2022-06-16 11:00:17', NULL, '2022-08-15 12:19:03', NULL, NULL),
(3, 4, 'adasd', '<iframe src=\"https://www.youtube.com/embed/8TvhoYtfMMs\" title=\"not heard to take chicken\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen ></iframe>', '1', 1, '2022-08-14 12:39:19', NULL, '2022-08-14 12:39:19', NULL, NULL),
(5, 6, 'dsada', '<iframe width=\"1349\" height=\"480\" src=\"https://www.youtube.com/embed/G5TwLNB0fIY\" title=\"GIANT CRAB - catch and cook - BOW n ARROW. Cooking on a camp fire. EP 83\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '1', 1, '2022-08-15 12:17:35', NULL, '2022-08-15 12:17:35', NULL, NULL),
(6, 1, 'test ch', '<iframe width=\"1349\" height=\"480\" src=\"https://www.youtube.com/embed/FtEiO4E6gDM\" title=\"Croatia ● Road to World Cup Final - 2018\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '1', 1, '2022-08-15 12:20:17', NULL, '2022-08-15 12:20:17', NULL, NULL),
(7, 8, 'Chapter One', '<iframe width=\"727\" height=\"409\" src=\"https://www.youtube.com/embed/lETuk2vjmBo\" title=\"01.আর্থিক বিবরণী || SSC Accounting Chapter 10- Part.01 || Class 9-10 Accounting Financial Statement\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '1', 1, '2022-09-24 11:29:44', NULL, '2022-09-24 11:29:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'seven', '1', 1, '2022-06-14 10:01:00', NULL, '2022-08-15 12:41:34', NULL, NULL),
(2, 'eight', '1', 1, '2022-06-14 10:01:00', NULL, '2022-08-15 12:41:37', NULL, NULL),
(3, 'One', '1', 1, '2022-06-15 11:27:57', NULL, '2022-08-15 12:41:40', NULL, NULL),
(4, 'Two', '1', 1, '2022-06-15 11:28:05', NULL, '2022-08-15 12:41:43', NULL, NULL),
(6, 'Nine', '1', 1, '2022-08-15 18:04:06', NULL, '2022-08-15 19:27:31', NULL, NULL),
(8, 'three', '1', 1, '2022-08-15 18:06:42', NULL, '2022-08-15 18:06:42', NULL, NULL),
(9, 'Ten', '1', 1, '2022-08-23 12:53:02', NULL, '2022-08-23 12:53:02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class_group`
--

CREATE TABLE `class_group` (
  `class_group_id` int(11) NOT NULL,
  `group_name` varchar(155) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_group`
--

INSERT INTO `class_group` (`class_group_id`, `group_name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Arts', 'Active', 1, '2022-08-15 16:40:20', NULL, '2022-08-15 16:43:41', NULL, NULL),
(2, 'Science', 'Active', 1, '2022-08-15 16:41:03', NULL, '2022-08-15 16:41:03', NULL, NULL),
(3, 'Commerce', 'Active', 1, '2022-08-15 16:41:17', NULL, '2022-08-15 16:41:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `class_group_joined`
--

CREATE TABLE `class_group_joined` (
  `class_group_jnt_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `class_group_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_group_joined`
--

INSERT INTO `class_group_joined` (`class_group_jnt_id`, `class_id`, `class_group_id`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(6, 6, 1, 1, '2022-08-23 16:11:01', NULL, NULL, NULL, NULL),
(7, 6, 2, 1, '2022-08-23 16:11:01', NULL, NULL, NULL, NULL),
(8, 6, 3, 1, '2022-08-23 16:11:01', NULL, NULL, NULL, NULL),
(9, 9, 1, 1, '2022-08-25 11:53:42', NULL, NULL, NULL, NULL),
(10, 9, 2, 1, '2022-08-25 11:53:42', NULL, NULL, NULL, NULL),
(11, 9, 3, 1, '2022-08-25 11:53:42', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(155) NOT NULL,
  `description` text DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `description`, `price`, `class_id`, `class_group_id`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Test Course', 'rwe rwe rwerwe', 200, NULL, NULL, 1, '2022-08-22 16:50:17', NULL, NULL, NULL, NULL),
(4, 'STT Course', 'dsfds fs fds fsd', 500, 6, 1, 1, '2022-08-23 16:24:01', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_subscribe`
--

CREATE TABLE `course_subscribe` (
  `course_subscribe_id` int(11) NOT NULL,
  `std_id` int(11) DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `subs_time` int(11) DEFAULT NULL COMMENT 'Value is calculated with month.',
  `status` enum('1','0') NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course_video`
--

CREATE TABLE `course_video` (
  `course_video_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumb` text DEFAULT NULL,
  `author` varchar(155) NOT NULL,
  `total_views` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_video`
--

INSERT INTO `course_video` (`course_video_id`, `course_id`, `title`, `URL`, `thumb`, `author`, `total_views`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 'not heard to take chicken', '<iframe width=\"727\" height=\"409\" src=\"https://www.youtube.com/embed/kKcMcXi8B-E\" title=\"Real Madrid vs Bayern Munich (4-2) |(6-3)agg | Extended Highlights & Goals | UCL 2016/17\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'thumb_1661260516_fb86fa16ed84600cd65d.jpg', 'test', 0, '1', 1, '2022-08-23 19:15:16', NULL, '2022-08-24 10:57:56', NULL, NULL),
(2, 4, 'foot sdfdsf sdf sd', '<iframe width=\"727\" height=\"409\" src=\"https://www.youtube.com/embed/Vhn2RkoWTgw\" title=\"1 in a Million Moments\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'thumb_1661262433_e80863a92ce3b7c61ffe.jpg', 'test', 0, '1', 1, '2022-08-23 19:47:13', NULL, '2022-08-24 10:57:13', NULL, NULL),
(3, 1, 'ghgfhfgh', '<iframe width=\"727\" height=\"409\" src=\"https://www.youtube.com/embed/T3aJ7LIBSVM\" title=\"PSG 2-0 Manchester City U.C.L 2022 Extended Highlights Full HD 1080P ???? 《حسن العيدروس》\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'thumb_1663475920_1fa1bb90e09755d54902.jpg', 'gfhfghfgh', 0, '1', 1, '2022-09-18 10:38:40', NULL, '2022-09-18 10:38:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `history_user_coin`
--

CREATE TABLE `history_user_coin` (
  `history_user_coin_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `chapter_joined_id` int(11) DEFAULT NULL,
  `mcq_joined_id` int(11) DEFAULT NULL,
  `qe_joined_id` int(11) DEFAULT NULL,
  `voc_mcq_joined_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double UNSIGNED NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_user_coin`
--

INSERT INTO `history_user_coin` (`history_user_coin_id`, `std_id`, `order_id`, `chapter_joined_id`, `mcq_joined_id`, `qe_joined_id`, `voc_mcq_joined_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 1, NULL, NULL, NULL, 4, NULL, 'Quiz coin get', 'Cr.', 1, 59, '2022-08-10 12:39:58', 0, '2022-08-10 12:39:58', NULL, NULL, NULL),
(2, 1, NULL, NULL, NULL, 4, NULL, 'Quiz coin get', 'Cr.', 1, 60, '2022-08-10 12:40:01', 0, '2022-08-10 12:40:01', NULL, NULL, NULL),
(3, 1, 4, NULL, NULL, NULL, NULL, 'Order product cost', 'Dr.', 200, 12, '2022-08-11 04:31:07', 0, '2022-08-11 04:31:07', NULL, NULL, NULL),
(4, 1, NULL, NULL, 3, NULL, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 14, '2022-08-14 06:50:31', 0, '2022-08-14 06:50:31', NULL, NULL, NULL),
(5, 1, NULL, NULL, 3, NULL, NULL, 'Vocabulary quiz coin get', 'Cr.', 2, 16, '2022-08-14 06:50:36', 0, '2022-08-14 06:50:36', NULL, NULL, NULL),
(6, 13, NULL, 4, NULL, NULL, NULL, 'Video quiz coin get', 'Cr.', 1, 1, '2022-09-24 05:31:05', 0, '2022-09-24 05:31:05', NULL, NULL, NULL),
(7, 13, NULL, NULL, 7, NULL, NULL, 'Skill development quiz coin get', 'Cr.', 1, 2, '2022-09-24 05:32:23', 0, '2022-09-24 05:32:23', NULL, NULL, NULL),
(8, 13, NULL, NULL, NULL, 5, NULL, 'Quiz coin get', 'Cr.', 1, 3, '2022-09-24 05:33:41', 0, '2022-09-24 05:33:41', NULL, NULL, NULL),
(9, 13, NULL, NULL, NULL, 5, NULL, 'Quiz coin get', 'Cr.', 1, 4, '2022-09-24 05:33:45', 0, '2022-09-24 05:33:45', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `history_user_point`
--

CREATE TABLE `history_user_point` (
  `history_user_point_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `chapter_joined_id` int(11) DEFAULT NULL,
  `mcq_joined_id` int(11) DEFAULT NULL,
  `qe_joined_id` int(11) DEFAULT NULL,
  `voc_mcq_joined_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double UNSIGNED NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_user_point`
--

INSERT INTO `history_user_point` (`history_user_point_id`, `std_id`, `order_id`, `chapter_joined_id`, `mcq_joined_id`, `qe_joined_id`, `voc_mcq_joined_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 1, NULL, NULL, NULL, 4, NULL, 'Quiz point get', 'Cr.', 1, 59, '2022-08-10 12:39:57', 0, '2022-08-10 12:39:57', NULL, NULL, NULL),
(2, 1, NULL, NULL, NULL, 4, NULL, 'Quiz point get', 'Cr.', 1, 60, '2022-08-10 12:40:01', 0, '2022-08-10 12:40:01', NULL, NULL, NULL),
(3, 1, NULL, NULL, 3, NULL, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 62, '2022-08-14 06:50:31', 0, '2022-08-14 06:50:31', NULL, NULL, NULL),
(4, 1, NULL, NULL, 3, NULL, NULL, 'Vocabulary quiz point get', 'Cr.', 2, 64, '2022-08-14 06:50:36', 0, '2022-08-14 06:50:36', NULL, NULL, NULL),
(5, 13, NULL, 4, NULL, NULL, NULL, 'Video quiz point get', 'Cr.', 1, 1, '2022-09-24 05:31:05', 0, '2022-09-24 05:31:05', NULL, NULL, NULL),
(6, 13, NULL, NULL, 7, NULL, NULL, 'Skill development quiz point get', 'Cr.', 1, 2, '2022-09-24 05:32:23', 0, '2022-09-24 05:32:23', NULL, NULL, NULL),
(7, 13, NULL, NULL, NULL, 5, NULL, 'Quiz point get', 'Cr.', 1, 3, '2022-09-24 05:33:40', 0, '2022-09-24 05:33:40', NULL, NULL, NULL),
(8, 13, NULL, NULL, NULL, 5, NULL, 'Quiz point get', 'Cr.', 1, 4, '2022-09-24 05:33:45', 0, '2022-09-24 05:33:45', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mcq_exam_joined`
--

CREATE TABLE `mcq_exam_joined` (
  `mcq_joined_id` int(11) NOT NULL,
  `skill_video_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mcq_exam_joined`
--

INSERT INTO `mcq_exam_joined` (`mcq_joined_id`, `skill_video_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(6, 3, 1, 2, NULL, 2, 2, 1, '2022-08-02 17:35:33', NULL, '2022-08-02 17:35:41', NULL, NULL),
(7, 3, 13, 1, 1, 1, 1, 13, '2022-09-24 11:32:16', NULL, '2022-09-24 11:32:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `std_id` int(11) DEFAULT NULL,
  `pymnt_method_id` int(11) DEFAULT NULL,
  `amount` double UNSIGNED NOT NULL,
  `entire_sale_discount` int(11) UNSIGNED DEFAULT NULL,
  `vat` int(11) UNSIGNED DEFAULT NULL,
  `delivery_charge` int(11) UNSIGNED DEFAULT NULL,
  `final_amount` double UNSIGNED NOT NULL,
  `global_address_id` int(11) NOT NULL,
  `status` enum('1','0','2','3') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '2=pandding,0=unpaid,1=paid,3=cancel',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `year` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `std_id`, `pymnt_method_id`, `amount`, `entire_sale_discount`, `vat`, `delivery_charge`, `final_amount`, `global_address_id`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 2, 550, NULL, NULL, NULL, 550, 0, '2', '2022-08-09 03:48:32', NULL, '2022-08-09 09:48:32', 1, NULL, '2022-08-09 09:48:32', NULL, NULL),
(2, 1, 2, 550, NULL, NULL, NULL, 550, 0, '2', '2022-08-09 03:58:10', NULL, '2022-08-09 09:58:10', 1, NULL, '2022-08-09 11:18:31', NULL, NULL),
(3, 1, 2, 550, NULL, NULL, NULL, 550, 0, '2', '2022-08-10 06:42:43', NULL, '2022-08-10 12:42:43', 1, NULL, '2022-08-10 12:42:43', NULL, NULL),
(4, 1, 1, 200, NULL, NULL, NULL, 200, 0, '2', '2022-08-11 04:31:07', NULL, '2022-08-11 10:31:07', 1, NULL, '2022-08-11 10:31:07', NULL, NULL),
(5, 1, 2, 500, NULL, NULL, NULL, 500, 0, '2', '2022-08-11 11:38:12', NULL, '2022-08-11 17:38:12', 1, NULL, '2022-08-11 17:38:12', NULL, NULL),
(6, 1, 2, 300, NULL, NULL, NULL, 300, 0, '2', '2022-08-14 06:43:57', NULL, '2022-08-14 12:43:57', 1, NULL, '2022-08-14 12:43:57', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `price` double UNSIGNED NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `total_price` double UNSIGNED NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `final_price` double UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) UNSIGNED DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `order_id`, `prod_id`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 1, 550, 1, 550, NULL, 550, '2022-08-09 09:48:32', 1, NULL, '2022-08-09 09:48:32', NULL, NULL),
(2, 2, 1, 550, 1, 550, NULL, 550, '2022-08-09 09:58:10', 1, NULL, '2022-08-09 09:58:10', NULL, NULL),
(3, 3, 1, 550, 1, 550, NULL, 550, '2022-08-10 12:42:43', 1, NULL, '2022-08-10 12:42:43', NULL, NULL),
(4, 4, 5, 200, 1, 200, NULL, 200, '2022-08-11 10:31:07', 1, NULL, '2022-08-11 10:31:07', NULL, NULL),
(5, 5, 5, 200, 1, 200, NULL, 200, '2022-08-11 17:38:12', 1, NULL, '2022-08-11 17:38:12', NULL, NULL),
(6, 5, 6, 300, 1, 300, NULL, 300, '2022-08-11 17:38:13', 1, NULL, '2022-08-11 17:38:13', NULL, NULL),
(7, 6, 6, 300, 1, 300, NULL, 300, '2022-08-14 12:43:57', 1, NULL, '2022-08-14 12:43:57', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `pymnt_method_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `icon` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`pymnt_method_id`, `type_name`, `icon`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Coin', '', 0, '2022-08-08 18:43:27', NULL, '2022-08-08 18:43:27', NULL, NULL),
(2, 'Bkash', '', 1, '2022-08-13 12:23:44', NULL, '2022-08-13 12:23:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `name` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `price` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `picture` varchar(155) DEFAULT NULL,
  `prod_cat_id` int(11) DEFAULT NULL,
  `product_type` enum('1','2') NOT NULL DEFAULT '1',
  `gender_type` enum('Man','Women','Both') NOT NULL DEFAULT 'Both',
  `description` text DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `store_id`, `name`, `quantity`, `price`, `unit`, `brand_id`, `picture`, `prod_cat_id`, `product_type`, `gender_type`, `description`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 1, 'Litio T-shirt SS', 7, 550, 1, 1, 'pro_1659613221_3c6fbb470fe10070edf3.png', 9, '1', 'Man', '<div><span style=\"color: rgb(35, 31, 32); font-family: \" gotham=\"\" ssm=\"\" a\",=\"\" \"gotham=\"\" b\",=\"\" arial,=\"\" helvetica,=\"\" sans-serif;=\"\" font-size:=\"\" 12px;\"=\"\">Light, fast drying and simple looking T-shirt made from super lightweight DELTAPEAK fabric. You can use it as base layer for summer trail running, hiking or cycling, but as a leisure wear it works great too. It keeps you dry by repelling your sweat at the surface of the fabric, where it can easily evaporate. This T-shirt giving you the impression to have nothing on your shoulders. Litio: when the weight matters.</span><br></div>', '1', '2022-08-04 11:40:20', 0, '2022-08-10 06:42:43', NULL, NULL, NULL),
(2, 1, 'Bjorn Merino Tshirt SS', 10, 600, 1, 1, 'pro_1659613310_fb048fd40963952bf4c0.png', 9, '1', 'Man', '<div><span style=\"color: rgb(35, 31, 32); font-family: \" gotham=\"\" ssm=\"\" a\",=\"\" \"gotham=\"\" b\",=\"\" arial,=\"\" helvetica,=\"\" sans-serif;=\"\" font-size:=\"\" 12px;\"=\"\">La conception innovante du t-shirt Bjorn allie le naturel de la laine mérinos et la résistance d’un fil synthétique autour duquel est enroulée la laine. Le résultat est un t-shirt aux propriétés respirantes et antibactériennes : sa fibre est plus résistante et plus souple, elle ne se perfore et ne se déchire pas. Le fait que le noyau en nylon soit caché dans les entrailles de la laine permet à la peau de n’être en contact qu’avec une laine agréable et chaude. Le t-shirt Bjorn en laine mérinos constitue un excellent choix pour n’importe quelle activité sportive tout au long de l’année. Comme toujours avec cette matière, il ne dégage pas d’odeurs même après plusieurs utilisations.</span><br></div>', '1', '2022-08-04 11:41:50', 0, '2022-08-08 05:43:38', NULL, NULL, NULL),
(3, 1, 'Exclusive Designed Gown 1piece Long Kurti Different kot', 10, 450, 1, 1, 'pro_1659613441_949e43fe8e0bbd938553.jpg', 10, '1', 'Women', '<div><h2 class=\"pdp-mod-section-title outer-title\" data-spm-anchor-id=\"a2a0e.pdp.0.i3.4ca820Wg20WgK1\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px 24px; font-family: Roboto-Medium; font-size: 16px; line-height: 52px; color: rgb(33, 33, 33); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; height: 52px; background: rgb(250, 250, 250);\">Product details of Exclusive Designed Gown 1piece Long Kurti Different koti, Gown Long Kurti For Stylish Women/Girls</h2><div class=\"pdp-product-detail\" data-spm=\"product_detail\" style=\"margin: 0px; padding: 0px; position: relative; color: rgb(0, 0, 0); font-family: Roboto, -apple-system, BlinkMacSystemFont, \" helvetica=\"\" neue\",=\"\" helvetica,=\"\" sans-serif;=\"\" font-size:=\"\" 12px;\"=\"\"><div class=\"pdp-product-desc \" style=\"margin: 0px; padding: 5px 14px 5px 24px; height: auto; overflow-y: hidden;\"><div class=\"html-content pdp-product-highlights\" style=\"margin: 0px; padding: 11px 0px 16px; word-break: break-word; border-bottom: 1px solid rgb(239, 240, 245); overflow: hidden;\"><ul class=\"\" style=\"margin: 0px; padding: 0px; list-style: none; overflow: hidden; columns: auto 2; column-gap: 32px;\"><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Product Type: 1Pice Long Kurti</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Color: Same As pic</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Main Material: Linen ,Sleeve.Long</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">;Very Nice And Comfortable</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Kamij; Body Size 36-44 Ani Body Use</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">100% Color Granti</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Kamij Long 50+</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">It is made of high quality materials,durable enought for your daily wearing</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Stylish and fashion design make you more attractive</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">This Dress is GORGEOUS! Loving the lace and how comfy it is! Don\\\'t miss out on this must have dress.</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">Great for Party,Daily,Casual,I am sure you will like it!</li><li class=\"\" style=\"margin: 0px; padding: 0px 0px 0px 15px; position: relative; font-size: 14px; line-height: 18px; text-align: left; list-style: none; word-break: break-word; break-inside: avoid;\">This lightweight, Dress is perfect for those carefree days</li></ul></div></div></div></div>', '1', '2022-08-04 11:44:01', 0, '2022-08-08 05:43:41', NULL, NULL, NULL),
(4, 1, 'Jamdani katan 2 piece katan Kameez katan Orna', 10, 400, 1, 1, 'pro_1659613562_ddfa5dd2a32ffe51de46.jpg', 10, '1', 'Women', '<h2 class=\"pdp-mod-section-title outer-title\" data-spm-anchor-id=\"a2a0e.pdp.0.i3.72a6Ic0HIc0HbO\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px 24px; font-family: Roboto-Medium; font-size: 16px; line-height: 52px; color: rgb(33, 33, 33); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; height: 52px; background: rgb(250, 250, 250);\">Product details of Jamdani katan 2 pi...</h2>', '1', '2022-08-04 11:46:02', 0, '2022-08-08 05:43:46', NULL, NULL, NULL),
(5, 1, 'Outdoor Small Mini Backpack Daypack Bookbags Laptop bag', 8, 200, 1, 1, 'pro_1659844580_50f934f011ed11247480.jpg', 11, '1', 'Both', '', '1', '2022-08-07 03:56:20', 0, '2022-08-11 11:38:12', NULL, NULL, NULL),
(6, 1, 'Cross body bag for men Official Messenger Bag Bike Ride', 8, 300, 1, 1, 'pro_1659844631_f00f21d7ca333b2f3dd8.jpg', 12, '1', 'Both', '', '1', '2022-08-07 03:57:11', 0, '2022-08-14 06:43:57', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `prod_cat_id` int(11) NOT NULL,
  `parent_pro_cat_id` int(11) NOT NULL,
  `product_category` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`prod_cat_id`, `parent_pro_cat_id`, `product_category`, `image`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 0, 'Man', NULL, '1', '2022-08-04 17:36:27', 1, '2022-08-04 17:36:27', NULL, NULL, NULL),
(2, 0, 'Women', NULL, '1', '2022-08-04 17:36:50', 1, '2022-08-04 17:36:50', NULL, NULL, NULL),
(3, 0, 'Bag', NULL, '1', '2022-08-04 17:37:01', 1, '2022-08-04 17:37:01', NULL, NULL, NULL),
(4, 0, 'Books', NULL, '1', '2022-08-04 17:37:09', 1, '2022-08-04 17:37:09', NULL, NULL, NULL),
(5, 0, 'Accessories', NULL, '1', '2022-08-04 17:37:22', 1, '2022-08-04 17:37:22', NULL, NULL, NULL),
(6, 0, 'Mobile', NULL, '1', '2022-08-04 17:37:46', 1, '2022-08-04 17:37:46', NULL, NULL, NULL),
(7, 0, 'Baby', NULL, '1', '2022-08-04 17:37:58', 1, '2022-08-04 17:37:58', NULL, NULL, NULL),
(8, 0, 'Health', NULL, '1', '2022-08-04 17:38:10', 1, '2022-08-04 17:38:10', NULL, NULL, NULL),
(9, 1, 'T-shirt', NULL, '1', '2022-08-04 17:39:12', 1, '2022-08-04 17:39:12', NULL, NULL, NULL),
(10, 2, 'Clothing', NULL, '1', '2022-08-04 17:42:44', 1, '2022-08-04 17:42:44', NULL, NULL, NULL),
(11, 3, 'Backpack', NULL, '1', '2022-08-07 09:52:45', 1, '2022-08-07 09:52:45', NULL, NULL, NULL),
(12, 3, 'Crossbody Bag', NULL, '1', '2022-08-07 09:53:07', 1, '2022-08-07 09:53:07', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_info`
--

CREATE TABLE `quiz_exam_info` (
  `quiz_exam_info_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `quiz_name` text NOT NULL,
  `total_questions` int(11) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_exam_info`
--

INSERT INTO `quiz_exam_info` (`quiz_exam_info_id`, `class_id`, `subject_id`, `quiz_name`, `total_questions`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(5, 6, 7, 'First Quize', 5, '1', 1, '2022-09-18 11:50:59', NULL, '2022-09-18 12:15:28', NULL, NULL),
(6, 1, 1, '7-First Exam', 4, '1', 1, '2022-09-19 12:07:47', NULL, '2022-09-19 12:07:47', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_joined`
--

CREATE TABLE `quiz_exam_joined` (
  `qe_joined_id` int(11) NOT NULL,
  `quiz_exam_info_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_exam_joined`
--

INSERT INTO `quiz_exam_joined` (`qe_joined_id`, `quiz_exam_info_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(3, 1, 1, 2, NULL, 2, 2, 1, '2022-08-02 12:46:30', NULL, '2022-08-02 12:46:38', NULL, NULL),
(4, 3, 1, 2, NULL, 2, 2, 1, '2022-08-10 18:39:50', NULL, '2022-08-10 18:40:01', NULL, NULL),
(5, 5, 13, 2, 2, 2, 2, 13, '2022-09-24 11:33:32', NULL, '2022-09-24 11:33:47', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_exam_questions`
--

CREATE TABLE `quiz_exam_questions` (
  `quiz_question_id` int(11) NOT NULL,
  `quiz_exam_info_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_exam_questions`
--

INSERT INTO `quiz_exam_questions` (`quiz_question_id`, `quiz_exam_info_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 5, 'Save করার shortcut key কোনটি?', 'Ctrl+C', 'Ctrl+V', 'Ctrl+S', 'Ctrl+D', 'three', '1', 1, '2022-07-13 18:03:14', NULL, '2022-09-18 11:57:23', NULL, NULL),
(3, 5, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-07-13 18:30:15', NULL, '2022-09-18 11:57:30', NULL, NULL),
(4, 5, 'Save করার Shortcut Key কোনটি?', 'Ctrl+C', 'Ctrl+V', 'Ctrl+S', 'Ctrl+D', 'three', '1', 1, '2022-07-16 16:16:18', NULL, '2022-09-18 11:57:37', NULL, NULL),
(5, 5, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-07-16 16:16:53', NULL, '2022-09-18 11:57:43', NULL, NULL),
(7, 6, 'Save করার Shortcut Key কোনটি?', 'Ctrl+C', 'Ctrl+V', 'Ctrl+S', 'Ctrl+D', 'three', '1', 1, '2022-09-19 12:08:55', NULL, '2022-09-19 12:08:55', NULL, NULL),
(8, 6, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-09-19 12:09:32', NULL, '2022-09-19 12:09:32', NULL, NULL),
(9, 6, 'Save করার Shortcut Key কোনটি?', 'Ctrl+C', 'Ctrl+S', 'Ctrl+V', 'Ctrl+D', 'two', '1', 1, '2022-09-19 12:10:14', NULL, '2022-09-19 12:10:14', NULL, NULL),
(10, 6, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-09-19 12:10:38', NULL, '2022-09-19 12:10:38', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `permission` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedby` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role`, `permission`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Student\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chapter_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User_roll\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Quiz_question\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Skill_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vocabulary_exam\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Store\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"ProductCategory\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Order\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Class_group\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Course_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Subscribe\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', 1, '2022-06-26 13:05:05', NULL, '2022-08-24 19:39:42', NULL, NULL),
(2, 'Maneger', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Student\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Class\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Subject\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Chapter\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Chapter_quiz\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"Chapter_video\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"0\",\"delete\":\"0\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"0\"},\"User_roll\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"0\",\"delete\":\"0\"}}', 1, '2022-06-26 18:16:14', NULL, '2022-06-26 18:16:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` text DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`settings_id`, `label`, `value`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'points_chapter_mcq', '1', 1, '2022-06-13 11:51:50', NULL, '2022-06-19 18:45:14', NULL, NULL),
(2, 'points_semister_mcq', '1', 1, '2022-06-13 11:52:49', NULL, '2022-06-13 11:52:49', NULL, NULL),
(3, 'points_vocabulary_mcq', '2', 1, '2022-06-13 11:53:50', NULL, '2022-07-28 18:23:40', NULL, NULL),
(7, 'points_video_mcq', '1', 1, '2022-07-19 09:59:40', NULL, '2022-07-19 09:59:40', NULL, NULL),
(8, 'vocabulary_quiz_view_frontEnd', '20', 1, '2022-07-26 12:57:41', NULL, '2022-07-26 13:00:05', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_questions`
--

CREATE TABLE `skill_questions` (
  `skill_question_id` int(11) NOT NULL,
  `skill_video_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skill_questions`
--

INSERT INTO `skill_questions` (`skill_question_id`, `skill_video_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 3, 'Save করার Shortcut Key কোনটি?', 'Ctrl+C', 'Ctrl+V', 'Ctrl+S', 'Ctrl+D', 'three', '1', 1, '2022-07-17 17:57:58', NULL, '2022-07-18 16:13:04', NULL, NULL),
(2, 3, 'প্রথম 6টি 7-এর অযুগ্ম গুনিতকের গড় কত?', '40', '41', '42', '43', 'three', '1', 1, '2022-07-17 17:58:36', NULL, '2022-07-18 16:13:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_subject`
--

CREATE TABLE `skill_subject` (
  `skill_subject_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skill_subject`
--

INSERT INTO `skill_subject` (`skill_subject_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Microsoft Word', '1', 1, '2022-07-17 11:01:29', NULL, '2022-07-17 11:01:29', NULL, NULL),
(2, 'Microsoft Excel', '1', 1, '2022-07-17 11:01:46', NULL, '2022-07-17 11:01:46', NULL, NULL),
(3, 'PowerPoint', '1', 1, '2022-07-17 11:02:01', NULL, '2022-07-17 11:02:01', NULL, NULL),
(4, 'OneNote', '1', 1, '2022-07-17 11:02:14', NULL, '2022-07-17 11:02:14', NULL, NULL),
(5, 'Outlook', '1', 1, '2022-07-17 11:02:29', NULL, '2022-07-17 11:02:29', NULL, NULL),
(6, 'Publisher', '1', 1, '2022-07-17 11:02:45', NULL, '2022-07-17 11:04:44', NULL, NULL),
(8, 'Admission test', '1', 1, '2022-07-17 11:05:17', NULL, '2022-07-17 11:05:17', NULL, NULL),
(9, 'Photoshop', '1', 1, '2022-07-17 11:05:28', NULL, '2022-07-17 11:05:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skill_video`
--

CREATE TABLE `skill_video` (
  `skill_video_id` int(11) NOT NULL,
  `skill_subject_id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `URL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumb` text DEFAULT NULL,
  `author` varchar(155) NOT NULL,
  `total_views` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skill_video`
--

INSERT INTO `skill_video` (`skill_video_id`, `skill_subject_id`, `title`, `URL`, `thumb`, `author`, `total_views`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(3, 1, 'not heard to take chicken', '<iframe src=\"https://www.youtube.com/embed/8TvhoYtfMMs\" title=\"not heard to take chicken\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen ></iframe>', 'thumb_1658124624_66ff63254c76965f9e25.jpg', 'Syed ibrahim erteza', 0, '1', 1, '2022-07-18 12:10:24', NULL, '2022-07-18 12:20:14', NULL, NULL),
(4, 1, 'Microsoft Excel easy  method', '<iframe src=\"https://www.youtube.com/embed/8TvhoYtfMMs\" title=\"not heard to take chicken\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen ></iframe>', 'thumb_1658125462_7d1fcb3cdd4e5a7983bc.jpg', 'Syed ibrahim erteza', 0, '1', 1, '2022-07-18 12:24:22', NULL, '2022-07-18 12:24:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `store_id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `quantity` int(11) UNSIGNED DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `purchase_date` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Last purchase price will be added here.',
  `is_default` enum('0','1') NOT NULL DEFAULT '0',
  `createdDtm` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`store_id`, `name`, `prod_id`, `quantity`, `unit`, `purchase_date`, `is_default`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES
(1, 'Default', NULL, NULL, NULL, '2022-08-03 12:19:10', '0', '2022-08-03 06:19:10', NULL, '2022-08-03 06:19:10', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `std_id` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `father_name` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `school_name` varchar(155) DEFAULT NULL,
  `gender` enum('Male','Female','Unisex') DEFAULT NULL,
  `religion` enum('Islam','Hindu','Christian','Buddhism') DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `class_id` int(5) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `institute` enum('School','Madrasha') NOT NULL DEFAULT 'School',
  `pic` varchar(100) NOT NULL,
  `point` int(11) DEFAULT NULL,
  `coin` int(11) DEFAULT NULL,
  `badge_id` int(11) DEFAULT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`std_id`, `phone`, `password`, `name`, `father_name`, `address`, `school_name`, `gender`, `religion`, `age`, `class_id`, `class_group_id`, `institute`, `pic`, `point`, `coin`, `badge_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1923121212, '7c222fb2927d828af22f592134e8932480637c0d', 'Murad', 'test', 'test', 'NSH School', 'Male', 'Islam', 28, 1, NULL, 'Madrasha', '', 64, 16, NULL, '1', NULL, '2022-06-14 10:39:40', NULL, '2022-08-16 12:37:45', NULL, NULL),
(3, 1923232323, '7c222fb2927d828af22f592134e8932480637c0d', 'test', 'test', 'test', 'NSH School', 'Male', 'Islam', 16, 1, NULL, 'Madrasha', '', 1050, 50, NULL, '1', NULL, '2022-06-14 11:56:10', NULL, '2022-08-16 12:37:48', NULL, NULL),
(4, 1923141516, '7c222fb2927d828af22f592134e8932480637c0d', 'Sumon', 'Sumon father', 'Test', 'NSH School', 'Male', 'Islam', 16, 2, NULL, 'School', '', 54, 54, NULL, '1', 1, '2022-06-14 18:46:11', NULL, '2022-08-16 12:37:50', NULL, NULL),
(6, 1989898989, '7c222fb2927d828af22f592134e8932480637c0d', 'sumonVie', 'test', 'test', 'test', 'Male', 'Islam', 16, 1, NULL, 'School', '', 2, 2, NULL, '1', NULL, '2022-08-02 19:19:56', NULL, '2022-08-16 12:37:52', NULL, NULL),
(10, 1923178654, '7c4a8d09ca3762af61e59520943dc26494f8941b', 'asdasd', 'asdsad', 'asdasd', 'asdsad', 'Male', 'Islam', 17, 6, 1, 'School', '', NULL, NULL, NULL, '1', 1, '2022-08-16 12:30:03', NULL, '2022-08-16 12:37:26', NULL, NULL),
(11, 1923112121, '7c222fb2927d828af22f592134e8932480637c0d', 'adeasdsa', 'asdsad', 'sadad', 'asdsad', 'Male', 'Islam', 23, 6, 3, 'School', '', NULL, NULL, NULL, '1', 1, '2022-08-16 12:40:13', NULL, '2022-08-16 12:59:40', NULL, NULL),
(12, 1923909090, '7c222fb2927d828af22f592134e8932480637c0d', 'ms', 'ms', 'nowapara', 'nsh', 'Male', 'Islam', 18, 6, 1, 'School', '', NULL, NULL, NULL, '1', NULL, '2022-08-16 16:54:10', NULL, '2022-08-16 16:54:10', NULL, NULL),
(13, 1714070775, '7c222fb2927d828af22f592134e8932480637c0d', 'habib', 'salim', 'nowapara', 'SHH', 'Male', 'Islam', 15, 6, 3, 'School', '', 4, 4, NULL, '1', 1, '2022-09-24 11:25:31', NULL, '2022-09-24 11:33:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `class_group_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `class_id`, `class_group_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 0, 'Bangla 1st', '1', 1, '2022-06-15 12:46:44', NULL, '2022-08-16 19:51:52', NULL, NULL),
(2, 1, 0, 'Bangla 2nd', '1', 1, '2022-06-15 12:50:05', NULL, '2022-08-16 19:51:50', NULL, NULL),
(3, 1, 0, 'English 1st', '1', 1, '2022-06-15 12:50:21', NULL, '2022-08-16 19:51:48', NULL, NULL),
(4, 1, 0, 'English 2nd', '1', 1, '2022-06-15 12:50:43', NULL, '2022-08-16 19:51:46', NULL, NULL),
(6, 2, 0, 'hgfh', '1', 1, '2022-08-14 19:32:56', NULL, '2022-08-16 19:51:42', NULL, NULL),
(7, 6, 1, 'General Science', '1', 1, '2022-08-15 19:40:58', NULL, '2022-08-15 19:44:04', NULL, NULL),
(8, 6, NULL, 'Bangla', '1', 1, '2022-08-16 18:05:59', NULL, '2022-08-17 09:59:54', NULL, NULL),
(9, 6, NULL, 'English', '1', 1, '2022-08-16 18:06:23', NULL, '2022-08-17 09:59:57', NULL, NULL),
(10, 6, 3, 'Accounting', '1', 1, '2022-08-16 18:07:30', NULL, '2022-08-16 18:07:30', NULL, NULL),
(11, 6, 2, 'Biology', '1', 1, '2022-08-16 18:08:32', NULL, '2022-08-16 18:08:32', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'murad@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Murad', NULL, NULL, NULL, 2, '1', 1, '2022-06-26 18:16:45', NULL, '2022-06-26 18:16:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary`
--

CREATE TABLE `vocabulary` (
  `voc_id` int(11) NOT NULL,
  `english` text NOT NULL,
  `bangla` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary`
--

INSERT INTO `vocabulary` (`voc_id`, `english`, `bangla`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'A little', 'সামান্য', 1, '2022-07-25 19:58:03', NULL, '2022-07-25 20:00:58', NULL, NULL),
(2, 'Register', 'নিবন্ধন', 1, '2022-07-25 20:21:01', NULL, '2022-07-25 20:21:01', NULL, NULL),
(3, 'Report', 'প্রতিবেদন', 1, '2022-07-25 20:21:27', NULL, '2022-07-25 20:21:27', NULL, NULL),
(4, 'Detail', 'বিস্তারিত', 1, '2022-07-25 20:21:51', NULL, '2022-07-25 20:21:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam`
--

CREATE TABLE `vocabulary_exam` (
  `voc_exam_id` int(11) NOT NULL,
  `published_date` date NOT NULL,
  `title` varchar(155) NOT NULL,
  `status` enum('Published','Unpublished') NOT NULL DEFAULT 'Unpublished',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_exam`
--

INSERT INTO `vocabulary_exam` (`voc_exam_id`, `published_date`, `title`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, '2022-07-28', 'Vocabulary first exam', 'Published', 1, '2022-07-26 18:09:59', NULL, '2022-07-28 18:22:32', NULL, NULL),
(2, '2022-07-29', 'Vocabulary Second Exam', 'Published', 1, '2022-07-27 10:24:34', NULL, '2022-07-27 20:04:38', NULL, NULL),
(3, '2022-08-02', 'test', 'Published', 1, '2022-08-02 17:37:53', NULL, '2022-08-02 17:38:16', NULL, NULL),
(4, '2022-08-14', 'today', 'Published', 1, '2022-08-14 12:49:55', NULL, '2022-08-14 12:50:05', NULL, NULL),
(5, '2022-09-24', 'first', 'Published', 1, '2022-09-24 11:51:27', NULL, '2022-09-24 11:51:58', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam_joined`
--

CREATE TABLE `vocabulary_exam_joined` (
  `voc_mcq_joined_id` int(11) NOT NULL,
  `voc_exam_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `correct_answers` int(11) DEFAULT NULL,
  `incorrect_answers` int(11) DEFAULT NULL,
  `earn_points` int(11) DEFAULT NULL,
  `earn_coins` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_exam_joined`
--

INSERT INTO `vocabulary_exam_joined` (`voc_mcq_joined_id`, `voc_exam_id`, `std_id`, `correct_answers`, `incorrect_answers`, `earn_points`, `earn_coins`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 1, 4, 2, NULL, 4, 4, 4, '2022-07-28 18:22:48', NULL, '2022-07-28 18:22:58', NULL, NULL),
(2, 3, 1, 2, NULL, 4, 4, 1, '2022-08-02 17:38:21', NULL, '2022-08-02 17:38:29', NULL, NULL),
(3, 4, 1, 2, NULL, 4, 4, 1, '2022-08-14 12:50:20', NULL, '2022-08-14 12:50:36', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_exam_r_quiz`
--

CREATE TABLE `vocabulary_exam_r_quiz` (
  `exam_quiz_id` int(11) NOT NULL,
  `voc_exam_id` int(11) NOT NULL,
  `voc_quiz_id` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_exam_r_quiz`
--

INSERT INTO `vocabulary_exam_r_quiz` (`exam_quiz_id`, `voc_exam_id`, `voc_quiz_id`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(18, 2, 2, 1, '2022-07-27 20:04:39', NULL, '2022-07-27 20:04:39', NULL, NULL),
(19, 2, 4, 1, '2022-07-27 20:04:39', NULL, '2022-07-27 20:04:39', NULL, NULL),
(20, 1, 1, 1, '2022-07-27 20:10:24', NULL, '2022-07-27 20:10:24', NULL, NULL),
(21, 1, 2, 1, '2022-07-27 20:10:24', NULL, '2022-07-27 20:10:24', NULL, NULL),
(24, 3, 1, 1, '2022-08-02 17:38:17', NULL, '2022-08-02 17:38:17', NULL, NULL),
(25, 3, 2, 1, '2022-08-02 17:38:17', NULL, '2022-08-02 17:38:17', NULL, NULL),
(28, 4, 1, 1, '2022-08-14 12:50:05', NULL, '2022-08-14 12:50:05', NULL, NULL),
(29, 4, 2, 1, '2022-08-14 12:50:05', NULL, '2022-08-14 12:50:05', NULL, NULL),
(33, 5, 1, 1, '2022-09-24 11:51:59', NULL, '2022-09-24 11:51:59', NULL, NULL),
(34, 5, 2, 1, '2022-09-24 11:51:59', NULL, '2022-09-24 11:51:59', NULL, NULL),
(35, 5, 4, 1, '2022-09-24 11:51:59', NULL, '2022-09-24 11:51:59', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_quiz`
--

CREATE TABLE `vocabulary_quiz` (
  `voc_quiz_id` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `one` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `two` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `three` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `four` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `correct_answer` enum('one','two','three','four') NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vocabulary_quiz`
--

INSERT INTO `vocabulary_quiz` (`voc_quiz_id`, `question`, `one`, `two`, `three`, `four`, `correct_answer`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'Describe মানে কি ?', 'বিস্তারিত', 'প্রতিবেদন', 'নিবন্ধন', 'বর্ণনা করা', 'four', '1', 1, '2022-07-26 10:44:17', NULL, '2022-07-26 10:44:17', NULL, NULL),
(2, 'Register মানে কি ?', 'বিস্তারিত', 'নিবন্ধন', 'প্রতিবেদন', 'বর্ণনা করা', 'two', '1', 1, '2022-07-26 10:45:37', NULL, '2022-07-26 10:45:55', NULL, NULL),
(4, 'Report মানে কি ?', 'বিস্তারিত', 'প্রতিবেদন', 'নিবন্ধন', 'বর্ণনা করা	', 'two', '1', 1, '2022-07-26 10:54:20', NULL, '2022-07-26 10:54:20', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `badge`
--
ALTER TABLE `badge`
  ADD PRIMARY KEY (`badge_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `chapter`
--
ALTER TABLE `chapter`
  ADD PRIMARY KEY (`chapter_id`),
  ADD KEY `parent_class_id` (`subject_id`);

--
-- Indexes for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  ADD PRIMARY KEY (`chapter_joined_id`);

--
-- Indexes for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  ADD PRIMARY KEY (`quiz_id`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `chapter_video`
--
ALTER TABLE `chapter_video`
  ADD PRIMARY KEY (`video_id`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `class_group`
--
ALTER TABLE `class_group`
  ADD PRIMARY KEY (`class_group_id`);

--
-- Indexes for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  ADD PRIMARY KEY (`class_group_jnt_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `class_group_id` (`class_group_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  ADD PRIMARY KEY (`course_subscribe_id`),
  ADD KEY `class_id` (`std_id`),
  ADD KEY `class_group_id` (`course_id`);

--
-- Indexes for table `course_video`
--
ALTER TABLE `course_video`
  ADD PRIMARY KEY (`course_video_id`),
  ADD KEY `chapter_id` (`course_id`);

--
-- Indexes for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  ADD PRIMARY KEY (`history_user_coin_id`),
  ADD KEY `sch_id` (`std_id`),
  ADD KEY `inv_id` (`order_id`);

--
-- Indexes for table `history_user_point`
--
ALTER TABLE `history_user_point`
  ADD PRIMARY KEY (`history_user_point_id`),
  ADD KEY `sch_id` (`std_id`),
  ADD KEY `inv_id` (`order_id`);

--
-- Indexes for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  ADD PRIMARY KEY (`mcq_joined_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `pymnt_type_id` (`pymnt_method_id`),
  ADD KEY `customer_id` (`std_id`) USING BTREE;

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `invoice_id` (`order_id`),
  ADD KEY `inv_exist_item_id` (`prod_id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`pymnt_method_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `prod_cat_id` (`prod_cat_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`prod_cat_id`);

--
-- Indexes for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  ADD PRIMARY KEY (`quiz_exam_info_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  ADD PRIMARY KEY (`qe_joined_id`);

--
-- Indexes for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  ADD PRIMARY KEY (`quiz_question_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settings_id`);

--
-- Indexes for table `skill_questions`
--
ALTER TABLE `skill_questions`
  ADD PRIMARY KEY (`skill_question_id`);

--
-- Indexes for table `skill_subject`
--
ALTER TABLE `skill_subject`
  ADD PRIMARY KEY (`skill_subject_id`);

--
-- Indexes for table `skill_video`
--
ALTER TABLE `skill_video`
  ADD PRIMARY KEY (`skill_video_id`),
  ADD KEY `chapter_id` (`skill_subject_id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`std_id`),
  ADD UNIQUE KEY `phone` (`phone`) USING BTREE,
  ADD KEY `class_id` (`class_id`),
  ADD KEY `badge_id` (`badge_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `parent_class_id` (`class_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vocabulary`
--
ALTER TABLE `vocabulary`
  ADD PRIMARY KEY (`voc_id`);

--
-- Indexes for table `vocabulary_exam`
--
ALTER TABLE `vocabulary_exam`
  ADD PRIMARY KEY (`voc_exam_id`);

--
-- Indexes for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  ADD PRIMARY KEY (`voc_mcq_joined_id`);

--
-- Indexes for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  ADD PRIMARY KEY (`exam_quiz_id`);

--
-- Indexes for table `vocabulary_quiz`
--
ALTER TABLE `vocabulary_quiz`
  ADD PRIMARY KEY (`voc_quiz_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `badge`
--
ALTER TABLE `badge`
  MODIFY `badge_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chapter`
--
ALTER TABLE `chapter`
  MODIFY `chapter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chapter_exam_joined`
--
ALTER TABLE `chapter_exam_joined`
  MODIFY `chapter_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `chapter_video`
--
ALTER TABLE `chapter_video`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `class_group`
--
ALTER TABLE `class_group`
  MODIFY `class_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  MODIFY `class_group_jnt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  MODIFY `course_subscribe_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_video`
--
ALTER TABLE `course_video`
  MODIFY `course_video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  MODIFY `history_user_coin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `history_user_point`
--
ALTER TABLE `history_user_point`
  MODIFY `history_user_point_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mcq_exam_joined`
--
ALTER TABLE `mcq_exam_joined`
  MODIFY `mcq_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `pymnt_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `prod_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  MODIFY `quiz_exam_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quiz_exam_joined`
--
ALTER TABLE `quiz_exam_joined`
  MODIFY `qe_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `quiz_exam_questions`
--
ALTER TABLE `quiz_exam_questions`
  MODIFY `quiz_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settings_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `skill_questions`
--
ALTER TABLE `skill_questions`
  MODIFY `skill_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `skill_subject`
--
ALTER TABLE `skill_subject`
  MODIFY `skill_subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `skill_video`
--
ALTER TABLE `skill_video`
  MODIFY `skill_video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `std_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vocabulary`
--
ALTER TABLE `vocabulary`
  MODIFY `voc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vocabulary_exam`
--
ALTER TABLE `vocabulary_exam`
  MODIFY `voc_exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vocabulary_exam_joined`
--
ALTER TABLE `vocabulary_exam_joined`
  MODIFY `voc_mcq_joined_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vocabulary_exam_r_quiz`
--
ALTER TABLE `vocabulary_exam_r_quiz`
  MODIFY `exam_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `vocabulary_quiz`
--
ALTER TABLE `vocabulary_quiz`
  MODIFY `voc_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chapter`
--
ALTER TABLE `chapter`
  ADD CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON UPDATE CASCADE;

--
-- Constraints for table `chapter_quiz`
--
ALTER TABLE `chapter_quiz`
  ADD CONSTRAINT `chapter_quiz_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class_group_joined`
--
ALTER TABLE `class_group_joined`
  ADD CONSTRAINT `class_group_joined_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_group_joined_ibfk_2` FOREIGN KEY (`class_group_id`) REFERENCES `class_group` (`class_group_id`) ON UPDATE CASCADE;

--
-- Constraints for table `course_subscribe`
--
ALTER TABLE `course_subscribe`
  ADD CONSTRAINT `course_subscribe_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `course_subscribe_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `history_user_coin`
--
ALTER TABLE `history_user_coin`
  ADD CONSTRAINT `history_user_coin_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `history_user_coin_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`) ON UPDATE CASCADE;

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `order_item_ibfk_3` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`) ON UPDATE CASCADE;

--
-- Constraints for table `quiz_exam_info`
--
ALTER TABLE `quiz_exam_info`
  ADD CONSTRAINT `quiz_exam_info_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`badge_id`) REFERENCES `badge` (`badge_id`) ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
